var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
let FavoriteService = class FavoriteService {
    constructor(prisma, jwt) {
        this.prisma = prisma;
        this.jwt = jwt;
    }
    async getMemberIdFromToken(token) {
        if (!token)
            throw new UnauthorizedException('缺少Token');
        try {
            const decoded = await this.jwt.verifyAsync(token, { ignoreExpiration: false });
            const id = Number(decoded?.sub);
            if (!id || decoded?.type !== 'member')
                throw new UnauthorizedException('Token无效');
            return id;
        }
        catch {
            throw new UnauthorizedException('Token无效');
        }
    }
    async list(token) {
        const memberId = await this.getMemberIdFromToken(token);
        return this.prisma.memberFavoriteProduct.findMany({ where: { memberId }, orderBy: { id: 'desc' }, include: { product: true } });
    }
    async add(token, productId) {
        const memberId = await this.getMemberIdFromToken(token);
        const product = await this.prisma.product.findUnique({ where: { id: Number(productId) } });
        if (!product)
            throw new BadRequestException('商品不存在');
        await this.prisma.memberFavoriteProduct.upsert({
            where: { memberId_productId: { memberId, productId: product.id } },
            create: { memberId, productId: product.id },
            update: {},
        });
        return { ok: true };
    }
    async remove(token, productId) {
        const memberId = await this.getMemberIdFromToken(token);
        const existing = await this.prisma.memberFavoriteProduct.findUnique({ where: { memberId_productId: { memberId, productId: Number(productId) } } });
        if (!existing)
            return { ok: true };
        await this.prisma.memberFavoriteProduct.delete({ where: { id: existing.id } });
        return { ok: true };
    }
};
FavoriteService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService, JwtService])
], FavoriteService);
export { FavoriteService };
