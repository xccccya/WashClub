var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Controller, Get, Headers, Post, Delete, Query, Param, ParseIntPipe } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { FavoriteService } from './favorite.service.js';
let FavoriteController = class FavoriteController {
    constructor(service) {
        this.service = service;
    }
    extractToken(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        return (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
    }
    async myList(headers, tokenParam) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.list(token);
    }
    async add(productId, headers, tokenParam) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.add(token, productId);
    }
    async remove(productId, headers, tokenParam) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.remove(token, productId);
    }
};
__decorate([
    Get('me/list'),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], FavoriteController.prototype, "myList", null);
__decorate([
    Post('me/:productId'),
    __param(0, Param('productId', ParseIntPipe)),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], FavoriteController.prototype, "add", null);
__decorate([
    Delete('me/:productId'),
    __param(0, Param('productId', ParseIntPipe)),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], FavoriteController.prototype, "remove", null);
FavoriteController = __decorate([
    ApiTags('favorite'),
    Controller('favorite'),
    __metadata("design:paramtypes", [FavoriteService])
], FavoriteController);
export { FavoriteController };
