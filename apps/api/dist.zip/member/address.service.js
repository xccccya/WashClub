var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
let AddressService = class AddressService {
    constructor(prisma, jwt) {
        this.prisma = prisma;
        this.jwt = jwt;
    }
    async getMemberIdFromToken(token) {
        if (!token)
            throw new UnauthorizedException('缺少Token');
        try {
            const decoded = await this.jwt.verifyAsync(token, { ignoreExpiration: false });
            const id = Number(decoded?.sub);
            if (!id || decoded?.type !== 'member')
                throw new UnauthorizedException('Token无效');
            return id;
        }
        catch {
            throw new UnauthorizedException('Token无效');
        }
    }
    async adminList(page = 1, pageSize = 20, keyword) {
        const where = keyword
            ? {
                OR: [
                    { province: { contains: keyword } },
                    { city: { contains: keyword } },
                    { district: { contains: keyword } },
                    { street: { contains: keyword } },
                    { detail: { contains: keyword } },
                    { phone: { contains: keyword } },
                    { member: { OR: [{ name: { contains: keyword } }, { phone: { contains: keyword } }] } },
                ],
            }
            : undefined;
        const [items, total] = await Promise.all([
            this.prisma.memberAddress.findMany({
                skip: (page - 1) * pageSize,
                take: pageSize,
                where,
                orderBy: { id: 'desc' },
                include: { member: { select: { id: true, name: true, phone: true } } },
            }),
            this.prisma.memberAddress.count({ where }),
        ]);
        return { items, total, page, pageSize };
    }
    listByMember(memberId) {
        return this.prisma.memberAddress.findMany({ where: { memberId }, orderBy: { id: 'desc' } });
    }
    async meList(token) {
        const memberId = await this.getMemberIdFromToken(token);
        return this.listByMember(memberId);
    }
    async meCreate(token, input) {
        const memberId = await this.getMemberIdFromToken(token);
        this.assertInput(input);
        const data = this.normalize(input);
        return this.prisma.memberAddress.create({ data: { ...data, memberId } });
    }
    async meUpdate(token, id, input) {
        const memberId = await this.getMemberIdFromToken(token);
        const existing = await this.prisma.memberAddress.findUnique({ where: { id } });
        if (!existing || existing.memberId !== memberId)
            throw new UnauthorizedException('无权操作该地址');
        if (input)
            this.assertPartialInput(input);
        const data = this.normalizePartial(input);
        return this.prisma.memberAddress.update({ where: { id }, data });
    }
    async meDelete(token, id) {
        const memberId = await this.getMemberIdFromToken(token);
        const existing = await this.prisma.memberAddress.findUnique({ where: { id } });
        if (!existing || existing.memberId !== memberId)
            throw new UnauthorizedException('无权操作该地址');
        await this.prisma.memberAddress.delete({ where: { id } });
        return { ok: true };
    }
    assertInput(input) {
        const { province, city, district, street, detail, phone, label } = input || {};
        if (!province || !city || !district || !street)
            throw new BadRequestException('省市区街道为必填');
        if (!detail || !detail.trim())
            throw new BadRequestException('详细地址为必填');
        if (!/^1\d{10}$/.test(String(phone || '')))
            throw new BadRequestException('手机号格式不正确');
        if (label && Array.from(label).length > 4)
            throw new BadRequestException('标签最多4个字');
    }
    assertPartialInput(input) {
        if (Object.prototype.hasOwnProperty.call(input, 'phone') && typeof input.phone !== 'undefined') {
            if (!/^1\d{10}$/.test(String(input.phone || '')))
                throw new BadRequestException('手机号格式不正确');
        }
        if (input.label && Array.from(input.label).length > 4)
            throw new BadRequestException('标签最多4个字');
    }
    normalize(input) {
        const data = { ...input };
        if (typeof data.label === 'string')
            data.label = data.label.trim() || null;
        return data;
    }
    normalizePartial(input) {
        const data = { ...input };
        if (Object.prototype.hasOwnProperty.call(data, 'label')) {
            if (typeof data.label === 'string')
                data.label = data.label.trim() || null;
        }
        return data;
    }
};
AddressService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService, JwtService])
], AddressService);
export { AddressService };
