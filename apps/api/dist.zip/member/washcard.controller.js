var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Body, Controller, Get, Headers, Param, Post, Query, Delete } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { WashCardService } from './washcard.service.js';
let WashCardController = class WashCardController {
    constructor(service) {
        this.service = service;
    }
    // 管理端
    adminList(page, pageSize, keyword) {
        return this.service.listAdmin(Number(page || 1), Number(pageSize || 20), keyword);
    }
    adminGet(id) { return this.service.getAdmin(Number(id)); }
    adminCreate(body) {
        if (!body?.ownerMemberId)
            throw new BadRequestException('ownerMemberId 必填');
        return this.service.createCard({ ownerMemberId: Number(body.ownerMemberId), name: body.name, totalTimes: body.totalTimes, remainingTimes: body.remainingTimes, expiryAt: body.expiryAt || null, isDefault: !!body?.isDefault });
    }
    adminAdd(id, body) {
        const c = Number(body?.count || 0);
        if (!Number.isFinite(c) || c <= 0)
            throw new BadRequestException('count 必须为正整数');
        return this.service.addTimes(Number(id), c, undefined, body?.remark, body?.purchaseOrderId);
    }
    adminDeduct(id, body) {
        const c = Number(body?.count || 0);
        if (!Number.isFinite(c) || c <= 0)
            throw new BadRequestException('count 必须为正整数');
        const reason = (body?.reason || 'BACKEND_DEDUCT');
        return this.service.deductTimes(Number(id), c, reason, { remark: body?.remark, vehicleId: body?.vehicleId, serviceOrderId: body?.serviceOrderId, refundRecordId: body?.refundRecordId });
    }
    adminLogs(id, page, pageSize) {
        return this.service.listLogs(Number(id), Number(page || 1), Number(pageSize || 20));
    }
    adminShares(id) { return this.service.listShares(Number(id)); }
    adminAddShare(id, body) { if (!body?.memberId)
        throw new BadRequestException('memberId 必填'); return this.service.addShare(Number(id), Number(body.memberId)); }
    adminRemoveShare(id, memberId) { return this.service.removeShare(Number(id), Number(memberId)); }
    adminSetDefault(id) { return this.service.setDefault(Number(id)); }
    adminDelete(id) { return this.service.deleteCard(Number(id)); }
    // 会员端
    async myList(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        return this.service.myCards(memberId);
    }
    async myGet(id, headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        return this.service.getCardForMember(memberId, Number(id));
    }
    async myLogs(id, headers, page, pageSize, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        return this.service.listLogsForMember(memberId, Number(id), Number(page || 1), Number(pageSize || 20));
    }
    async mySetDefault(id, headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        return this.service.setDefaultForOwner(memberId, Number(id));
    }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '洗车卡列表（管理员，分页/关键词）' }),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminList", null);
__decorate([
    Get(':id'),
    ApiOperation({ summary: '洗车卡详情（管理员）' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminGet", null);
__decorate([
    Post('create'),
    ApiOperation({ summary: '创建洗车卡（管理员）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminCreate", null);
__decorate([
    Post(':id/add'),
    ApiOperation({ summary: '增加洗车卡次数（管理员）' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminAdd", null);
__decorate([
    Post(':id/deduct'),
    ApiOperation({ summary: '扣减洗车卡次数（管理员）' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminDeduct", null);
__decorate([
    Get(':id/logs'),
    ApiOperation({ summary: '洗车卡变更记录（管理员）' }),
    __param(0, Param('id')),
    __param(1, Query('page')),
    __param(2, Query('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminLogs", null);
__decorate([
    Get(':id/shares'),
    ApiOperation({ summary: '共享成员列表（管理员）' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminShares", null);
__decorate([
    Post(':id/shares'),
    ApiOperation({ summary: '添加共享成员（管理员）' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminAddShare", null);
__decorate([
    Post(':id/shares/:memberId/remove'),
    ApiOperation({ summary: '移除共享成员（管理员）' }),
    __param(0, Param('id')),
    __param(1, Param('memberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminRemoveShare", null);
__decorate([
    Post(':id/set-default'),
    ApiOperation({ summary: '设置会员默认洗车卡（管理员）' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminSetDefault", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除洗车卡（管理员）' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WashCardController.prototype, "adminDelete", null);
__decorate([
    Get('me/list'),
    ApiOperation({ summary: '我的洗车卡列表（会员端）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], WashCardController.prototype, "myList", null);
__decorate([
    Get('me/:id'),
    ApiOperation({ summary: '我的洗车卡详情（会员端）' }),
    __param(0, Param('id')),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", Promise)
], WashCardController.prototype, "myGet", null);
__decorate([
    Get('me/:id/logs'),
    ApiOperation({ summary: '我的洗车卡记录（会员端）' }),
    __param(0, Param('id')),
    __param(1, Headers()),
    __param(2, Query('page')),
    __param(3, Query('pageSize')),
    __param(4, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String, String, String]),
    __metadata("design:returntype", Promise)
], WashCardController.prototype, "myLogs", null);
__decorate([
    Post('me/:id/set-default'),
    ApiOperation({ summary: '设置我的默认洗车卡（会员端）' }),
    __param(0, Param('id')),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", Promise)
], WashCardController.prototype, "mySetDefault", null);
WashCardController = __decorate([
    ApiTags('wash-card'),
    Controller('wash-card'),
    __metadata("design:paramtypes", [WashCardService])
], WashCardController);
export { WashCardController };
