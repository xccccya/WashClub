var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { MemberLevelService } from './level.service.js';
let MemberLevelController = class MemberLevelController {
    constructor(service) {
        this.service = service;
    }
    list() { return this.service.list(); }
    create(body) { return this.service.create(body); }
    update(id, body) {
        return this.service.update(Number(id), body);
    }
    remove(id) { return this.service.remove(Number(id)); }
};
__decorate([
    Get(),
    ApiOperation({ summary: '会员等级列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MemberLevelController.prototype, "list", null);
__decorate([
    Post(),
    ApiOperation({ summary: '创建会员等级' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MemberLevelController.prototype, "create", null);
__decorate([
    Put(':id'),
    ApiOperation({ summary: '更新会员等级' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MemberLevelController.prototype, "update", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除会员等级' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MemberLevelController.prototype, "remove", null);
MemberLevelController = __decorate([
    ApiTags('member-level'),
    Controller('member-level'),
    __metadata("design:paramtypes", [MemberLevelService])
], MemberLevelController);
export { MemberLevelController };
