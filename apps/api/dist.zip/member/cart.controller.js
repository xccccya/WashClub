var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Headers, Param, ParseIntPipe, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CartService } from './cart.service.js';
let CartController = class CartController {
    constructor(service) {
        this.service = service;
    }
    extractToken(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        return (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
    }
    async myList(headers, tokenParam, onlyChecked) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.list(token, String(onlyChecked || '').toLowerCase() === 'true');
    }
    async myAdd(headers, tokenParam, body) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.add(token, body);
    }
    async myUpdate(id, headers, tokenParam, body) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.update(token, id, body);
    }
    async toggleAll(headers, tokenParam, body) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.toggleAll(token, !!body?.checked);
    }
    async clearChecked(headers, tokenParam) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.clearChecked(token);
    }
    async myDelete(id, headers, tokenParam) {
        const token = this.extractToken(headers, tokenParam);
        return this.service.remove(token, id);
    }
};
__decorate([
    Get('me/list'),
    __param(0, Headers()),
    __param(1, Query('token')),
    __param(2, Query('onlyChecked')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "myList", null);
__decorate([
    Post('me/add'),
    __param(0, Headers()),
    __param(1, Query('token')),
    __param(2, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "myAdd", null);
__decorate([
    Put('me/:id'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers()),
    __param(2, Query('token')),
    __param(3, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, Object, Object]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "myUpdate", null);
__decorate([
    Post('me/toggle-all'),
    __param(0, Headers()),
    __param(1, Query('token')),
    __param(2, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "toggleAll", null);
__decorate([
    Delete('me/clear-checked'),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "clearChecked", null);
__decorate([
    Delete('me/:id'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, Object]),
    __metadata("design:returntype", Promise)
], CartController.prototype, "myDelete", null);
CartController = __decorate([
    ApiTags('cart'),
    Controller('cart'),
    __metadata("design:paramtypes", [CartService])
], CartController);
export { CartController };
