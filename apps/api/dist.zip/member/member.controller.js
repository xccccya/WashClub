var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Headers, Param, Post, Put, Query, BadRequestException } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { MemberService } from './member.service.js';
let MemberController = class MemberController {
    constructor(service) {
        this.service = service;
    }
    list(page, pageSize, keyword) {
        return this.service.list(Number(page || 1), Number(pageSize || 20), keyword);
    }
    // 放在参数路由之前，避免被 ":id" 匹配到
    me(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.getProfileByToken(token);
    }
    setActive(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.setActiveByToken(token);
    }
    get(id) {
        return this.service.findById(Number(id));
    }
    create(body) {
        // 昵称长度校验：≤10 个字符（按 Unicode 码点计）
        const nameTrim = String(body?.name || '').trim();
        if (!nameTrim)
            throw new BadRequestException('昵称不能为空');
        if (Array.from(nameTrim).length > 10)
            throw new BadRequestException('昵称长度不可超过10个字符');
        if (!body?.levelId)
            throw new BadRequestException('会员等级为必选项');
        if (!body?.categoryId)
            throw new BadRequestException('会员分类为必选项');
        return this.service.create(body);
    }
    update(id, body) {
        // 若传入 name，则进行长度与非空校验
        if (Object.prototype.hasOwnProperty.call(body, 'name')) {
            const nameTrim = String(body?.name ?? '').trim();
            if (!nameTrim)
                throw new BadRequestException('昵称不能为空');
            if (Array.from(nameTrim).length > 10)
                throw new BadRequestException('昵称长度不可超过10个字符');
        }
        // 仅当显式传入这些字段时才强制校验；
        if (Object.prototype.hasOwnProperty.call(body, 'levelId') && body.levelId == null)
            throw new BadRequestException('会员等级为必选项');
        if (Object.prototype.hasOwnProperty.call(body, 'categoryId') && body.categoryId == null)
            throw new BadRequestException('会员分类为必选项');
        return this.service.update(Number(id), body);
    }
    setPassword(id, body) {
        return this.service.setPassword(Number(id), body.password);
    }
    remove(id) {
        return this.service.remove(Number(id));
    }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '会员列表（分页/关键词）' }),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "list", null);
__decorate([
    Get('me/profile'),
    ApiOperation({ summary: '查询当前会员资料（支持token参数）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "me", null);
__decorate([
    Post('me/active'),
    ApiOperation({ summary: '心跳：设置会员在线活跃状态' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "setActive", null);
__decorate([
    Get(':id'),
    ApiOperation({ summary: '获取会员详情' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "get", null);
__decorate([
    Post('create'),
    ApiOperation({ summary: '创建会员' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "create", null);
__decorate([
    Put(':id'),
    ApiOperation({ summary: '更新会员资料' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "update", null);
__decorate([
    Put(':id/password'),
    ApiOperation({ summary: '设置/重置会员密码（管理员）' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "setPassword", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除会员' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "remove", null);
MemberController = __decorate([
    ApiTags('member'),
    Controller('member'),
    __metadata("design:paramtypes", [MemberService])
], MemberController);
export { MemberController };
