var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
let MemberCategoryService = class MemberCategoryService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    list() {
        return this.prisma.memberCategory.findMany({ orderBy: [{ weight: 'desc' }, { id: 'asc' }] });
    }
    create(data) {
        return this.prisma.memberCategory.create({ data });
    }
    update(id, data) {
        return this.prisma.memberCategory.update({ where: { id }, data });
    }
    remove(id) {
        return this.prisma.memberCategory.delete({ where: { id } });
    }
};
MemberCategoryService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService])
], MemberCategoryService);
export { MemberCategoryService };
