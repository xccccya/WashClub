var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
let MemberTagService = class MemberTagService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async list() {
        const rows = await this.prisma.memberTag.findMany({ orderBy: { id: 'asc' }, include: { _count: { select: { members: true } } } });
        return rows.map((r) => ({ id: r.id, name: r.name, isSystem: !!r.isSystem, memberCount: Number(r?._count?.members || 0) }));
    }
    create(data) { return this.prisma.memberTag.create({ data }); }
    async update(id, data) {
        const tag = await this.prisma.memberTag.findUnique({ where: { id } });
        if (!tag)
            throw new BadRequestException('标签不存在');
        if (tag.isSystem)
            throw new BadRequestException('系统默认标签不可编辑');
        return this.prisma.memberTag.update({ where: { id }, data });
    }
    async remove(id) {
        const tag = await this.prisma.memberTag.findUnique({ where: { id } });
        if (!tag)
            throw new BadRequestException('标签不存在');
        if (tag.isSystem)
            throw new BadRequestException('系统默认标签不可删除');
        return this.prisma.memberTag.delete({ where: { id } });
    }
    async listMembers(tagId, page = 1, pageSize = 20, keyword) {
        if (!tagId)
            throw new BadRequestException('标签ID无效');
        const where = {
            tags: { some: { id: tagId } },
            ...(keyword ? { OR: [{ name: { contains: keyword } }, { phone: { contains: keyword } }] } : {}),
        };
        const [itemsRaw, total] = await Promise.all([
            this.prisma.member.findMany({
                skip: (page - 1) * pageSize,
                take: pageSize,
                where,
                orderBy: { id: 'desc' },
                select: { id: true, name: true, phone: true, createdAt: true, level: { select: { id: true, name: true } }, category: { select: { id: true, name: true } } },
            }),
            this.prisma.member.count({ where }),
        ]);
        return { items: itemsRaw, total, page, pageSize };
    }
};
MemberTagService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService])
], MemberTagService);
export { MemberTagService };
