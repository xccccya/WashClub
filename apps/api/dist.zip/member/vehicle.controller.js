var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Body, Controller, Delete, Get, Headers, Param, Post, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { VehicleService } from './vehicle.service.js';
let VehicleController = class VehicleController {
    constructor(service) {
        this.service = service;
    }
    // 管理端列表
    adminList(page, pageSize, keyword) {
        return this.service.adminList(Number(page || 1), Number(pageSize || 20), keyword);
    }
    // 按会员查询
    listByMember(memberId) {
        return this.service.listByMember(Number(memberId));
    }
    // 新增车辆（管理员）
    createForMember(memberId, body) {
        if (!body?.plateNumber)
            throw new BadRequestException('车牌号为必填项');
        if (!body?.typeMain)
            throw new BadRequestException('车辆主类型为必填项');
        return this.service.createForMember(Number(memberId), body);
    }
    // 新增车辆（管理员-按会员手机号）
    createForMemberByPhone(body) {
        const phone = String(body?.phone || '').trim();
        if (!/^1\d{10}$/.test(phone))
            throw new BadRequestException('会员手机号格式不正确');
        if (!body?.plateNumber)
            throw new BadRequestException('车牌号为必填项');
        if (!body?.typeMain)
            throw new BadRequestException('车辆主类型为必填项');
        return this.service.createForMemberByPhone(phone, body);
    }
    // 修改车辆
    updateVehicle(id, body) {
        return this.service.updateVehicle(Number(id), body);
    }
    // 删除车辆
    remove(id) {
        return this.service.deleteVehicle(Number(id));
    }
    // 设置默认车辆
    setDefault(id) {
        return this.service.setDefault(Number(id));
    }
    // 模糊搜索车牌（管理端/队列用）
    search(q, limit) {
        return this.service.searchByPlateLike(String(q || ''), Number(limit || 15));
    }
    // 创建游客车辆
    createGuest(body) {
        if (!body?.plateNumber)
            throw new BadRequestException('车牌号为必填项');
        return this.service.createGuestVehicle(body);
    }
    // 将游客车辆绑定到会员
    bindMember(id, memberId) {
        return this.service.bindGuestVehicle(Number(id), Number(memberId));
    }
    // 我的车辆（会员端）
    async myVehicles(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        return this.service.listByMember(memberId);
    }
    // 新增我的车辆（会员端）
    async myCreate(headers, tokenParam, body) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        const memberId = await this.service.getMemberIdFromToken(token);
        if (!body?.plateNumber)
            throw new BadRequestException('车牌号为必填项');
        if (!body?.typeMain)
            throw new BadRequestException('车辆主类型为必填项');
        return this.service.createForMember(memberId, body);
    }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '车辆列表（管理员，分页/关键词）' }),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "adminList", null);
__decorate([
    Get('member/:memberId'),
    ApiOperation({ summary: '按会员ID查询车辆' }),
    __param(0, Param('memberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "listByMember", null);
__decorate([
    Post('member/:memberId'),
    ApiOperation({ summary: '为会员新增车辆（管理员）' }),
    __param(0, Param('memberId')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "createForMember", null);
__decorate([
    Post('member/by-phone'),
    ApiOperation({ summary: '按手机号为会员新增车辆（管理员）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "createForMemberByPhone", null);
__decorate([
    Put(':id'),
    ApiOperation({ summary: '修改车辆信息' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "updateVehicle", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除车辆' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "remove", null);
__decorate([
    Post(':id/set-default'),
    ApiOperation({ summary: '设置默认车辆' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "setDefault", null);
__decorate([
    Get('search'),
    ApiOperation({ summary: '模糊搜索车牌（管理端/队列）' }),
    __param(0, Query('q')),
    __param(1, Query('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "search", null);
__decorate([
    Post('guest/create'),
    ApiOperation({ summary: '创建游客车辆' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "createGuest", null);
__decorate([
    Post(':id/bind-member/:memberId'),
    ApiOperation({ summary: '将游客车辆绑定到会员' }),
    __param(0, Param('id')),
    __param(1, Param('memberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], VehicleController.prototype, "bindMember", null);
__decorate([
    Get('me/list'),
    ApiOperation({ summary: '我的车辆列表（会员端）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], VehicleController.prototype, "myVehicles", null);
__decorate([
    Post('me/create'),
    ApiOperation({ summary: '新增我的车辆（会员端）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __param(2, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], VehicleController.prototype, "myCreate", null);
VehicleController = __decorate([
    ApiTags('vehicle'),
    Controller('vehicle'),
    __metadata("design:paramtypes", [VehicleService])
], VehicleController);
export { VehicleController };
