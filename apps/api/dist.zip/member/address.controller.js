var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Headers, Param, Post, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { AddressService } from './address.service.js';
let AddressController = class AddressController {
    constructor(service) {
        this.service = service;
    }
    // 管理端：分页列表
    adminList(page, pageSize, keyword) {
        return this.service.adminList(Number(page || 1), Number(pageSize || 20), keyword);
    }
    // 管理端：按会员ID
    listByMember(memberId) {
        return this.service.listByMember(Number(memberId));
    }
    // 会员端：我的列表
    async myList(headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.meList(token);
    }
    // 会员端：新增
    async myCreate(headers, tokenParam, body) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.meCreate(token, body);
    }
    // 会员端：修改
    async myUpdate(id, headers, tokenParam, body) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.meUpdate(token, Number(id), body);
    }
    // 会员端：删除
    async myDelete(id, headers, tokenParam) {
        const authHeader = (headers?.authorization || headers?.Authorization);
        const token = (authHeader ? authHeader.replace(/^Bearer\s+/i, '') : '') || tokenParam || '';
        return this.service.meDelete(token, Number(id));
    }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '收货地址列表（管理员，分页/关键词）' }),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], AddressController.prototype, "adminList", null);
__decorate([
    Get('member/:memberId'),
    ApiOperation({ summary: '按会员ID查询收货地址（管理员）' }),
    __param(0, Param('memberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AddressController.prototype, "listByMember", null);
__decorate([
    Get('me/list'),
    ApiOperation({ summary: '我的收货地址列表（会员端）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "myList", null);
__decorate([
    Post('me/create'),
    ApiOperation({ summary: '新增我的收货地址（会员端）' }),
    __param(0, Headers()),
    __param(1, Query('token')),
    __param(2, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "myCreate", null);
__decorate([
    Put('me/:id'),
    ApiOperation({ summary: '修改我的收货地址（会员端）' }),
    __param(0, Param('id')),
    __param(1, Headers()),
    __param(2, Query('token')),
    __param(3, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "myUpdate", null);
__decorate([
    Delete('me/:id'),
    ApiOperation({ summary: '删除我的收货地址（会员端）' }),
    __param(0, Param('id')),
    __param(1, Headers()),
    __param(2, Query('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "myDelete", null);
AddressController = __decorate([
    ApiTags('address'),
    Controller('address'),
    __metadata("design:paramtypes", [AddressService])
], AddressController);
export { AddressController };
