var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
let MemberLevelService = class MemberLevelService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    list() { return this.prisma.memberLevel.findMany({ orderBy: [{ weight: 'desc' }, { id: 'asc' }] }); }
    async create(data) {
        const shouldBeDefault = !!data?.isDefault;
        return this.prisma.$transaction(async (tx) => {
            if (shouldBeDefault) {
                await tx.memberLevel.updateMany({ data: { isDefault: false }, where: { isDefault: true } });
            }
            else {
                const existsDefault = await tx.memberLevel.count({ where: { isDefault: true } });
                if (existsDefault === 0) {
                    // 系统必须存在唯一默认等级：如果还没有默认，则将新建的设为默认
                    data.isDefault = true;
                }
            }
            return tx.memberLevel.create({ data });
        });
    }
    async update(id, data) {
        const wantUnsetDefault = data?.isDefault === false;
        const wantSetDefault = data?.isDefault === true;
        return this.prisma.$transaction(async (tx) => {
            if (wantSetDefault) {
                // 设为默认：清除其他默认
                await tx.memberLevel.updateMany({ data: { isDefault: false }, where: { id: { not: id } } });
                return tx.memberLevel.update({ where: { id }, data: { ...data, isDefault: true } });
            }
            if (wantUnsetDefault) {
                const current = await tx.memberLevel.findUnique({ where: { id } });
                if (current?.isDefault) {
                    const othersDefault = await tx.memberLevel.count({ where: { id: { not: id }, isDefault: true } });
                    if (othersDefault === 0) {
                        throw new BadRequestException('系统需要存在一个默认等级，请先将其他等级设为默认');
                    }
                }
            }
            return tx.memberLevel.update({ where: { id }, data });
        });
    }
    async remove(id) {
        return this.prisma.$transaction(async (tx) => {
            const level = await tx.memberLevel.findUnique({ where: { id } });
            if (!level)
                return null;
            if (level.isDefault) {
                const otherDefault = await tx.memberLevel.count({ where: { id: { not: id }, isDefault: true } });
                if (otherDefault === 0) {
                    throw new BadRequestException('请先将其他等级设为默认后，再删除当前默认等级');
                }
            }
            // 将该等级下的会员 levelId 置空
            await tx.member.updateMany({ where: { levelId: id }, data: { levelId: null } });
            return tx.memberLevel.delete({ where: { id } });
        });
    }
};
MemberLevelService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService])
], MemberLevelService);
export { MemberLevelService };
