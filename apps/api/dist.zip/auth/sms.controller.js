var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { PrismaService } from '../prisma.service.js';
import { AdminGuard } from './admin.guard.js';
import { RequirePerm } from './perm.decorator.js';
let SmsAdminController = class SmsAdminController {
    constructor(prisma) {
        this.prisma = prisma;
    }
    // 短信记录列表（仅查询）
    async listSmsCodes(phone, purpose, used, page, pageSize) {
        const p = Math.max(1, Number(page || 1) | 0);
        const ps = Math.min(100, Math.max(1, Number(pageSize || 20) | 0));
        const where = {};
        if (phone && /^\d{3,}$/.test(phone))
            where.phone = phone;
        if (purpose === 'login' || purpose === 'resetPwd')
            where.purpose = purpose;
        if (used === '0')
            where.usedAt = null;
        if (used === '1')
            where.usedAt = { not: null };
        const [total, items] = await this.prisma.$transaction([
            this.prisma.smsCode.count({ where }),
            this.prisma.smsCode.findMany({ where, orderBy: { id: 'desc' }, skip: (p - 1) * ps, take: ps }),
        ]);
        return { total, page: p, pageSize: ps, items };
    }
};
__decorate([
    Get('sms-codes'),
    ApiOperation({ summary: '短信验证码记录列表（仅查询）' }),
    RequirePerm('system-sms'),
    __param(0, Query('phone')),
    __param(1, Query('purpose')),
    __param(2, Query('used')),
    __param(3, Query('page')),
    __param(4, Query('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], SmsAdminController.prototype, "listSmsCodes", null);
SmsAdminController = __decorate([
    ApiTags('system'),
    Controller('system'),
    UseGuards(AdminGuard),
    __metadata("design:paramtypes", [PrismaService])
], SmsAdminController);
export { SmsAdminController };
