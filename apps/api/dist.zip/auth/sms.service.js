var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable, BadRequestException } from '@nestjs/common';
import { createRequire } from 'node:module';
let SmsService = class SmsService {
    get secretId() {
        const v = process.env.TENCENTCLOUD_SECRET_ID;
        if (!v)
            throw new BadRequestException('未配置 TENCENTCLOUD_SECRET_ID');
        return v;
    }
    get secretKey() {
        const v = process.env.TENCENTCLOUD_SECRET_KEY;
        if (!v)
            throw new BadRequestException('未配置 TENCENTCLOUD_SECRET_KEY');
        return v;
    }
    get region() {
        return process.env.SMS_REGION || 'ap-nanjing';
    }
    get appId() {
        const v = process.env.SMS_SDK_APP_ID;
        if (!v)
            throw new BadRequestException('未配置 SMS_SDK_APP_ID');
        return v;
    }
    get signName() {
        const v = process.env.SMS_SIGN_NAME;
        if (!v)
            throw new BadRequestException('未配置 SMS_SIGN_NAME');
        return v;
    }
    get templateId() {
        const v = process.env.SMS_TEMPLATE_ID;
        if (!v)
            throw new BadRequestException('未配置 SMS_TEMPLATE_ID');
        return v;
    }
    /** 发送登录验证码 */
    async sendLoginCode(phone, code, minutes) {
        const e164Phone = this.toE164(phone);
        const require = createRequire(import.meta.url);
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const tencentcloud = require('tencentcloud-sdk-nodejs');
        const SmsClient = tencentcloud.sms.v20210111.Client;
        const client = new SmsClient({
            credential: { secretId: this.secretId, secretKey: this.secretKey },
            region: this.region,
            profile: { httpProfile: { endpoint: 'sms.tencentcloudapi.com', reqMethod: 'POST', reqTimeout: 10 } },
        });
        const params = {
            SmsSdkAppId: this.appId,
            SignName: this.signName,
            TemplateId: this.templateId,
            TemplateParamSet: [code, String(minutes)],
            PhoneNumberSet: [e164Phone],
        };
        try {
            await client.SendSms(params);
        }
        catch (e) {
            throw new BadRequestException(`短信发送失败: ${e?.message || e}`);
        }
    }
    toE164(phone) {
        const p = String(phone).trim();
        if (!/^1\d{10}$/.test(p))
            throw new BadRequestException('手机号格式不正确');
        return `+86${p}`;
    }
};
SmsService = __decorate([
    Injectable()
], SmsService);
export { SmsService };
