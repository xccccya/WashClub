var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, UnauthorizedException, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
import { PERM_KEY } from './perm.decorator.js';
let AdminGuard = class AdminGuard {
    constructor(jwt, prisma, reflector) {
        this.jwt = jwt;
        this.prisma = prisma;
        this.reflector = reflector;
    }
    async canActivate(context) {
        const req = context.switchToHttp().getRequest();
        const authHeader = req?.headers?.authorization || req?.headers?.Authorization;
        if (!authHeader)
            throw new UnauthorizedException('未登录');
        const m = /^Bearer\s+(.+)$/.exec(String(authHeader));
        const token = m?.[1];
        if (!token)
            throw new UnauthorizedException('未登录');
        let decoded;
        try {
            decoded = this.jwt.verify(token);
        }
        catch {
            throw new UnauthorizedException('登录已过期');
        }
        if (!decoded || decoded.type !== 'admin' || !decoded.sub)
            throw new UnauthorizedException('身份无效');
        const userId = Number(decoded.sub);
        if (!Number.isFinite(userId) || userId <= 0)
            throw new UnauthorizedException('身份无效');
        const user = await this.prisma.user.findUnique({ where: { id: userId }, include: { roleRef: true } });
        if (!user)
            throw new UnauthorizedException('账户不存在');
        if (user.roleId && user.roleRef && !user.roleRef.enabled)
            throw new ForbiddenException('该角色已被禁用');
        // 权限校验
        const requiredPerm = this.reflector.getAllAndOverride(PERM_KEY, [context.getHandler(), context.getClass()]);
        if (requiredPerm) {
            const perms = Array.isArray(user.roleRef?.permissions) ? user.roleRef?.permissions : [];
            if (!(perms.includes('*') || perms.includes(requiredPerm))) {
                throw new ForbiddenException('无权限');
            }
        }
        // 注入 request.user 便于后续使用
        req.user = { id: user.id, roleId: user.roleId, role: user.role };
        return true;
    }
};
AdminGuard = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [JwtService, PrismaService, Reflector])
], AdminGuard);
export { AdminGuard };
