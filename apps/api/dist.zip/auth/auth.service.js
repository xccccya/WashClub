var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, UnauthorizedException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
import { SmsService } from './sms.service.js';
import * as crypto from 'node:crypto';
let AuthService = class AuthService {
    constructor(prisma, jwt, sms) {
        this.prisma = prisma;
        this.jwt = jwt;
        this.sms = sms;
        // ====== WeChat MiniApp One-Tap Login Support ======
        this.wechatAccessTokenCache = null;
        this.wechatAccessTokenInFlight = null;
    }
    hashPassword(raw) {
        return crypto.createHash('sha256').update(raw).digest('hex');
    }
    get wechatAppId() {
        const v = process.env.WECHAT_MINIAPP_APPID || process.env.WECHAT_APPID;
        if (!v)
            throw new BadRequestException('后台未配置 WECHAT_MINIAPP_APPID');
        return v;
    }
    get wechatSecret() {
        const v = process.env.WECHAT_MINIAPP_SECRET || process.env.WECHAT_SECRET;
        if (!v)
            throw new BadRequestException('后台未配置 WECHAT_MINIAPP_SECRET');
        return v;
    }
    async getWechatAccessToken() {
        const now = Date.now();
        if (this.wechatAccessTokenCache && this.wechatAccessTokenCache.expiresAt - 30000 > now) {
            return this.wechatAccessTokenCache.token;
        }
        if (this.wechatAccessTokenInFlight)
            return this.wechatAccessTokenInFlight;
        this.wechatAccessTokenInFlight = (async () => {
            const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${encodeURIComponent(this.wechatAppId)}&secret=${encodeURIComponent(this.wechatSecret)}`;
            let lastErr = null;
            for (let attempt = 0; attempt < 3; attempt++) {
                const controller = new AbortController();
                const timeout = setTimeout(() => controller.abort(), 12000);
                try {
                    const resp = await fetch(url, { signal: controller.signal });
                    clearTimeout(timeout);
                    if (!resp.ok) {
                        lastErr = new Error(`${resp.status} ${resp.statusText}`);
                    }
                    else {
                        const data = (await resp.json());
                        if (data?.access_token && data?.expires_in) {
                            this.wechatAccessTokenCache = {
                                token: data.access_token,
                                expiresAt: Date.now() + Number(data.expires_in) * 1000,
                            };
                            return this.wechatAccessTokenCache.token;
                        }
                        lastErr = new Error(`响应异常: ${JSON.stringify(data)}`);
                    }
                }
                catch (e) {
                    clearTimeout(timeout);
                    lastErr = e;
                }
                // 简单退避
                await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
            }
            throw new BadRequestException(`获取微信access_token网络失败: ${lastErr?.message || lastErr}`);
        })();
        try {
            return await this.wechatAccessTokenInFlight;
        }
        finally {
            this.wechatAccessTokenInFlight = null;
        }
    }
    async exchangeWechatPhoneNumberByCode(code) {
        if (!code)
            throw new BadRequestException('缺少手机号动态令牌code');
        const accessToken = await this.getWechatAccessToken();
        const url = `https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=${encodeURIComponent(accessToken)}`;
        let data;
        {
            let lastErr = null;
            for (let attempt = 0; attempt < 2; attempt++) {
                const controller = new AbortController();
                const timeout = setTimeout(() => controller.abort(), 12000);
                try {
                    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }), signal: controller.signal });
                    clearTimeout(timeout);
                    if (!resp.ok) {
                        lastErr = new Error(`${resp.status} ${resp.statusText}`);
                    }
                    else {
                        data = await resp.json();
                        break;
                    }
                }
                catch (e) {
                    clearTimeout(timeout);
                    lastErr = e;
                }
                await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
            }
            if (!data)
                throw new BadRequestException(`获取手机号网络失败: ${lastErr?.message || lastErr}`);
        }
        // 期望结构: { errcode:0, errmsg:'ok', phone_info: { phoneNumber: '1xxxxxxxxxx', purePhoneNumber: '1xxxxxxxxxx' } }
        if (data?.errcode !== 0 || !data?.phone_info?.purePhoneNumber) {
            throw new BadRequestException(`获取手机号失败: ${JSON.stringify(data)}`);
        }
        return String(data.phone_info.purePhoneNumber);
    }
    // 暴露给外部调用：通过微信实时手机号 code 换取手机号
    async resolvePhoneByWechatCode(code) {
        const phone = await this.exchangeWechatPhoneNumberByCode(code);
        return { phone };
    }
    async exchangeWechatOpenIdByJsCode(jsCode) {
        if (!jsCode)
            throw new BadRequestException('缺少wx.login返回的jsCode');
        const url = `https://api.weixin.qq.com/sns/jscode2session?appid=${encodeURIComponent(this.wechatAppId)}&secret=${encodeURIComponent(this.wechatSecret)}&js_code=${encodeURIComponent(jsCode)}&grant_type=authorization_code`;
        let data;
        {
            let lastErr = null;
            for (let attempt = 0; attempt < 2; attempt++) {
                const controller = new AbortController();
                const timeout = setTimeout(() => controller.abort(), 12000);
                try {
                    const resp = await fetch(url, { signal: controller.signal });
                    clearTimeout(timeout);
                    if (!resp.ok) {
                        lastErr = new Error(`${resp.status} ${resp.statusText}`);
                    }
                    else {
                        data = await resp.json();
                        break;
                    }
                }
                catch (e) {
                    clearTimeout(timeout);
                    lastErr = e;
                }
                await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
            }
            if (!data)
                throw new BadRequestException(`换取openid网络失败: ${lastErr?.message || lastErr}`);
        }
        if (!data?.openid)
            throw new BadRequestException(`换取openid失败: ${JSON.stringify(data)}`);
        return { openid: String(data.openid), unionid: data?.unionid ? String(data.unionid) : undefined };
    }
    maskPhone(phone) {
        return String(phone).replace(/^(\d{3})\d+(\d{4})$/, '$1****$2');
    }
    generateRandomName() {
        const rnd = Math.random().toString(36).slice(2, 8);
        return `注册会员${rnd}`;
    }
    async generateUniqueMemberUid() {
        // 生成唯一8位数字UID，最多尝试若干次
        for (let i = 0; i < 20; i++) {
            const uid = Math.floor(10000000 + Math.random() * 90000000);
            const exists = await this.prisma.member.findUnique({ where: { uid }, select: { id: true } }).catch(() => null);
            if (!exists)
                return uid;
        }
        // 极端情况下仍冲突，退化到时间 + 随机的取模
        return Number(String(Date.now()).slice(-8));
    }
    async wechatOneTapLogin(params) {
        const { phoneCode, jsCode } = params;
        // Step1: 获取手机号
        const phone = await this.exchangeWechatPhoneNumberByCode(phoneCode);
        // Step2: 获取 openid
        const { openid } = await this.exchangeWechatOpenIdByJsCode(jsCode);
        // Step3: 查询该 openid 是否已绑定到其他手机号
        const openIdOwner = await this.prisma.member.findFirst({ where: { weixinOpenId: openid }, select: { id: true, phone: true } });
        if (openIdOwner && openIdOwner.phone !== phone) {
            return { ok: false, code: 'OPENID_BOUND_CONFLICT', maskedPhone: this.maskPhone(openIdOwner.phone), message: `该微信号已绑定手机号：${this.maskPhone(openIdOwner.phone)}` };
        }
        // Step4: 查找/创建手机号会员
        let member = await this.prisma.member.findUnique({ where: { phone }, include: { tags: true } });
        let createdNew = false;
        if (!member) {
            const uid = await this.generateUniqueMemberUid();
            // 注册新会员时，必须分配“默认等级”
            const defaultLevel = await this.prisma.memberLevel.findFirst({ where: { isDefault: true } });
            if (!defaultLevel) {
                throw new BadRequestException('系统未配置默认会员等级，请先在管理后台设置');
            }
            member = await this.prisma.member.create({ data: { uid, name: this.generateRandomName(), phone, levelId: defaultLevel.id }, include: { tags: true } });
            createdNew = true;
        }
        if (!member)
            throw new BadRequestException('登录失败，请重试');
        // Step5: 如未绑定 openid 则绑定
        let justBoundOpenId = false;
        if (!member.weixinOpenId) {
            justBoundOpenId = true;
            await this.prisma.member.update({ where: { id: member.id }, data: { weixinOpenId: openid } });
        }
        // Step6: 为不同场景自动打系统标签
        try {
            // id=3: 微信一键登录自动创建账号（仅新建时）
            if (createdNew) {
                const has3 = (member.tags || []).some((t) => t.id === 3);
                if (!has3) {
                    await this.prisma.member.update({ where: { id: member.id }, data: { tags: { connect: [{ id: 3 }] } } });
                }
            }
            // id=4: 微信一键登录绑定已有账号（仅非新建账号且本次完成绑定时）
            if (!createdNew && justBoundOpenId) {
                const refreshed = await this.prisma.member.findUnique({ where: { id: member.id }, include: { tags: true } });
                const has4 = (refreshed?.tags || []).some((t) => t.id === 4);
                if (!has4) {
                    await this.prisma.member.update({ where: { id: member.id }, data: { tags: { connect: [{ id: 4 }] } } });
                }
            }
        }
        catch { }
        // Step7: 发放登录 token
        const token = await this.jwt.signAsync({ sub: member.id, type: 'member', phone: member.phone }, { expiresIn: '7d' });
        return { ok: true, token, user: { id: member.id, name: member.name, role: 'member', phone: member.phone }, createdNew, justBoundOpenId };
    }
    // 管理后台用户登录（保留）
    async loginAdminByPassword(phone, password) {
        const user = await this.prisma.user.findUnique({ where: { phone }, include: { roleRef: true } });
        if (!user)
            throw new UnauthorizedException('账户不存在');
        const hashed = this.hashPassword(password);
        if (user.password !== hashed)
            throw new UnauthorizedException('密码错误');
        if (user.roleId && user.roleRef && !user.roleRef.enabled)
            throw new ForbiddenException('该角色已被禁用');
        const permissions = Array.isArray(user.roleRef?.permissions) ? user.roleRef?.permissions : [];
        const expiresIn = '1d';
        const token = await this.jwt.signAsync({ sub: user.id, type: 'admin', role: user.role, roleId: user.roleId, phone: user.phone }, { expiresIn });
        let expiresAt = undefined;
        try {
            const decoded = this.jwt.decode(token);
            const exp = Number(decoded?.exp || 0);
            if (exp)
                expiresAt = exp * 1000;
        }
        catch { }
        return { token, expiresAt, user: { id: user.id, name: user.name ?? '', role: user.role, phone: user.phone, roleId: user.roleId ?? null, permissions } };
    }
    // 小程序会员登录
    async loginMemberByPassword(phone, password) {
        const member = await this.prisma.member.findUnique({ where: { phone } });
        if (!member || !member.password)
            throw new UnauthorizedException('会员账号不存在或未设置密码');
        const hashed = this.hashPassword(password);
        if (member.password !== hashed)
            throw new UnauthorizedException('密码错误');
        // 正式：令牌 7 天过期
        const token = await this.jwt.signAsync({ sub: member.id, type: 'member', phone: member.phone }, { expiresIn: '7d' });
        return { token, user: { id: member.id, name: member.name, role: 'member', phone: member.phone } };
    }
    // 发送短信验证码（5分钟有效，含频控：60秒内同一手机号不重复发送；每日最多10条）
    async sendLoginCode(rawPhone, rawPurpose) {
        const phone = String(rawPhone || '').trim();
        if (!/^1\d{10}$/.test(phone))
            throw new BadRequestException('手机号格式不正确');
        const purpose = rawPurpose === 'resetPwd' ? 'resetPwd' : (rawPurpose === 'changePhone' ? 'changePhone' : 'login');
        const now = new Date();
        const fiveMinLater = new Date(Date.now() + 5 * 60 * 1000);
        // 频控：60秒内不重复发
        const oneMinuteAgo = new Date(Date.now() - 60 * 1000);
        const recent = await this.prisma.smsCode.findFirst({ where: { phone, createdAt: { gt: oneMinuteAgo }, purpose }, orderBy: { id: 'desc' } });
        if (recent)
            throw new BadRequestException('发送太频繁，请稍后再试');
        // 当日最多 10 条
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const countToday = await this.prisma.smsCode.count({ where: { phone, createdAt: { gte: startOfDay }, purpose } });
        if (countToday >= 10)
            throw new BadRequestException('当日发送次数过多，请明日再试');
        // 生成 6 位数字验证码
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        // 发送短信
        await this.sms.sendLoginCode(phone, code, 5);
        // 存库
        await this.prisma.smsCode.create({ data: { phone, code, purpose, expiresAt: fiveMinLater } });
        return { ok: true };
    }
    // 短信验证码登录：自动注册、签发 token，并使验证码失效
    async loginMemberByCode(rawPhone, rawCode) {
        const phone = String(rawPhone || '').trim();
        const code = String(rawCode || '').trim();
        if (!/^1\d{10}$/.test(phone))
            throw new BadRequestException('手机号格式不正确');
        if (!/^\d{6}$/.test(code))
            throw new BadRequestException('验证码格式不正确');
        const now = new Date();
        const record = await this.prisma.smsCode.findFirst({ where: { phone, code, purpose: 'login', usedAt: null }, orderBy: { id: 'desc' } });
        if (!record)
            throw new UnauthorizedException('验证码错误');
        if (record.expiresAt < now)
            throw new UnauthorizedException('验证码已过期');
        // 标记为已使用
        await this.prisma.smsCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
        // 查找/自动注册会员
        let member = await this.prisma.member.findUnique({ where: { phone }, include: { tags: true } });
        let createdNew = false;
        if (!member) {
            const uid = await this.generateUniqueMemberUid();
            const defaultLevel = await this.prisma.memberLevel.findFirst({ where: { isDefault: true } });
            if (!defaultLevel)
                throw new BadRequestException('系统未配置默认会员等级，请先在管理后台设置');
            member = await this.prisma.member.create({ data: { uid, name: this.generateRandomName(), phone, levelId: defaultLevel.id }, include: { tags: true } });
            createdNew = true;
        }
        if (!member)
            throw new BadRequestException('登录失败，请重试');
        // 新注册（短信验证码登录自动创建账号）：id=2 标签
        if (createdNew) {
            try {
                const has2 = (member.tags || []).some((t) => t.id === 2);
                if (!has2) {
                    await this.prisma.member.update({ where: { id: member.id }, data: { tags: { connect: [{ id: 2 }] } } });
                }
            }
            catch { }
        }
        const token = await this.jwt.signAsync({ sub: member.id, type: 'member', phone: member.phone }, { expiresIn: '7d' });
        return { token, user: { id: member.id, name: member.name, role: 'member', phone: member.phone }, createdNew };
    }
    // 重置会员密码（校验短信验证码 purpose: 'resetPwd'，设置新密码）
    async resetMemberPasswordByCode(rawPhone, rawCode, newPassword) {
        const phone = String(rawPhone || '').trim();
        const code = String(rawCode || '').trim();
        if (!/^1\d{10}$/.test(phone))
            throw new BadRequestException('手机号格式不正确');
        if (!/^\d{6}$/.test(code))
            throw new BadRequestException('验证码格式不正确');
        if (!newPassword || newPassword.length < 6)
            throw new BadRequestException('新密码至少6位');
        const now = new Date();
        const record = await this.prisma.smsCode.findFirst({ where: { phone, code, purpose: 'resetPwd', usedAt: null }, orderBy: { id: 'desc' } });
        if (!record)
            throw new UnauthorizedException('验证码错误');
        if (record.expiresAt < now)
            throw new UnauthorizedException('验证码已过期');
        // 标记验证码已使用
        await this.prisma.smsCode.update({ where: { id: record.id }, data: { usedAt: new Date() } });
        // 查找会员并更新密码
        const member = await this.prisma.member.findUnique({ where: { phone } });
        if (!member)
            throw new UnauthorizedException('会员账号不存在');
        const hashed = this.hashPassword(newPassword);
        await this.prisma.member.update({ where: { id: member.id }, data: { password: hashed } });
        return { ok: true };
    }
    // 更换会员手机号（校验 purpose: 'changePhone' 验证码），若通过则更新会员手机号
    async changeMemberPhoneByCode(rawOldPhone, rawNewPhone, rawCode) {
        const oldPhone = String(rawOldPhone || '').trim();
        const newPhone = String(rawNewPhone || '').trim();
        const code = String(rawCode || '').trim();
        if (!/^1\d{10}$/.test(oldPhone) || !/^1\d{10}$/.test(newPhone))
            throw new BadRequestException('手机号格式不正确');
        if (oldPhone === newPhone)
            throw new BadRequestException('新旧手机号一致');
        if (!/^\d{6}$/.test(code))
            throw new BadRequestException('验证码格式不正确');
        // 校验验证码（下发给新手机号）
        const now = new Date();
        const record = await this.prisma.smsCode.findFirst({ where: { phone: newPhone, code, purpose: 'changePhone', usedAt: null }, orderBy: { id: 'desc' } });
        if (!record)
            throw new UnauthorizedException('验证码错误');
        if (record.expiresAt < now)
            throw new UnauthorizedException('验证码已过期');
        // 查找旧手机号会员
        const member = await this.prisma.member.findUnique({ where: { phone: oldPhone } });
        if (!member)
            throw new UnauthorizedException('会员账号不存在');
        // 检查新手机号是否被占用
        const exists = await this.prisma.member.findUnique({ where: { phone: newPhone } }).catch(() => null);
        if (exists)
            throw new BadRequestException('该手机号已被其他账号绑定');
        // 更新手机号，并使验证码失效
        await this.prisma.$transaction([
            this.prisma.member.update({ where: { id: member.id }, data: { phone: newPhone } }),
            this.prisma.smsCode.update({ where: { id: record.id }, data: { usedAt: new Date() } })
        ]);
        return { ok: true };
    }
    async updateAdminNickname(userId, name) {
        const updated = await this.prisma.user.update({ where: { id: userId }, data: { name } });
        return { id: updated.id, name: updated.name };
    }
    async updateAdminPassword(userId, oldPassword, newPassword) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user)
            throw new UnauthorizedException('账户不存在');
        const oldHashed = this.hashPassword(oldPassword);
        if (user.password !== oldHashed)
            throw new UnauthorizedException('旧密码不正确');
        const newHashed = this.hashPassword(newPassword);
        await this.prisma.user.update({ where: { id: userId }, data: { password: newHashed } });
        return { ok: true };
    }
};
AuthService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService, JwtService, SmsService])
], AuthService);
export { AuthService };
