import { SetMetadata } from '@nestjs/common';
// 统一 metadata key
export const PERM_KEY = 'perm';
export const RequirePerm = (perm) => SetMetadata(PERM_KEY, perm);
