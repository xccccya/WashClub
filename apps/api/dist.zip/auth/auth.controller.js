var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Post, BadRequestException } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { AuthService } from './auth.service.js';
import { IsNotEmpty, IsString, MinLength, IsInt, IsIn, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
class LoginDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], LoginDto.prototype, "phone", void 0);
__decorate([
    IsString(),
    MinLength(6),
    __metadata("design:type", String)
], LoginDto.prototype, "password", void 0);
class SendCodeDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], SendCodeDto.prototype, "phone", void 0);
__decorate([
    IsString(),
    IsOptional(),
    IsIn(['login', 'resetPwd', 'changePhone']),
    __metadata("design:type", String)
], SendCodeDto.prototype, "purpose", void 0);
class LoginByCodeDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], LoginByCodeDto.prototype, "phone", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], LoginByCodeDto.prototype, "code", void 0);
class ResetPasswordDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "phone", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "code", void 0);
__decorate([
    IsString(),
    MinLength(6),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "newPassword", void 0);
class ChangePhoneByCodeDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ChangePhoneByCodeDto.prototype, "oldPhone", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ChangePhoneByCodeDto.prototype, "newPhone", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ChangePhoneByCodeDto.prototype, "code", void 0);
class ResolvePhoneDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], ResolvePhoneDto.prototype, "code", void 0);
class UpdateNicknameDto {
}
__decorate([
    Type(() => Number),
    IsInt(),
    __metadata("design:type", Number)
], UpdateNicknameDto.prototype, "userId", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], UpdateNicknameDto.prototype, "name", void 0);
class UpdatePasswordDto {
}
__decorate([
    Type(() => Number),
    IsInt(),
    __metadata("design:type", Number)
], UpdatePasswordDto.prototype, "userId", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], UpdatePasswordDto.prototype, "oldPassword", void 0);
__decorate([
    IsString(),
    MinLength(6),
    __metadata("design:type", String)
], UpdatePasswordDto.prototype, "newPassword", void 0);
class WechatOneTapDto {
}
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], WechatOneTapDto.prototype, "phoneCode", void 0);
__decorate([
    IsString(),
    IsNotEmpty(),
    __metadata("design:type", String)
], WechatOneTapDto.prototype, "jsCode", void 0);
let AuthController = class AuthController {
    constructor(service) {
        this.service = service;
    }
    login(dto) {
        return this.service.loginMemberByPassword(dto.phone, dto.password);
    }
    // 发送短信验证码（登录用途）
    sendLoginCode(dto) {
        return this.service.sendLoginCode(dto.phone, dto.purpose);
    }
    // 短信验证码登录
    loginByCode(dto) {
        return this.service.loginMemberByCode(dto.phone, dto.code);
    }
    // 重置会员密码（通过短信验证码）
    resetPassword(dto) {
        return this.service.resetMemberPasswordByCode(dto.phone, dto.code, dto.newPassword);
    }
    // 短信验证码更换会员手机号（用途 purpose: changePhone）
    changePhone(dto) {
        return this.service.changeMemberPhoneByCode(dto.oldPhone, dto.newPhone, dto.code);
    }
    // 通过微信实时手机号能力返回的 code 获取纯手机号
    resolvePhone(dto) {
        return this.service.resolvePhoneByWechatCode(dto.code);
    }
    // 微信一键登录：手机号快速验证 + wx.login 获取 openid
    wechatOneTap(dto) {
        if (!dto?.phoneCode || !dto?.jsCode)
            throw new BadRequestException('缺少必要参数');
        return this.service.wechatOneTapLogin({ phoneCode: dto.phoneCode, jsCode: dto.jsCode });
    }
    adminLogin(dto) {
        return this.service.loginAdminByPassword(dto.phone, dto.password);
    }
    updateAdminNickname(dto) {
        return this.service.updateAdminNickname(Number(dto.userId), dto.name);
    }
    updateAdminPassword(dto) {
        return this.service.updateAdminPassword(Number(dto.userId), dto.oldPassword, dto.newPassword);
    }
};
__decorate([
    Post('login'),
    ApiOperation({ summary: '会员登录（账号+密码）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [LoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "login", null);
__decorate([
    Post('send-code'),
    ApiOperation({ summary: '发送短信验证码（登录/注册/重置/换号）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [SendCodeDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "sendLoginCode", null);
__decorate([
    Post('login/code'),
    ApiOperation({ summary: '短信验证码登录/注册' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [LoginByCodeDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "loginByCode", null);
__decorate([
    Post('reset-password'),
    ApiOperation({ summary: '重置会员密码（短信验证码）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ResetPasswordDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "resetPassword", null);
__decorate([
    Post('change-phone'),
    ApiOperation({ summary: '更换会员手机号（短信验证码）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ChangePhoneByCodeDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "changePhone", null);
__decorate([
    Post('wechat/resolve-phone'),
    ApiOperation({ summary: '微信手机号组件 code 换取手机号' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ResolvePhoneDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "resolvePhone", null);
__decorate([
    Post('wechat/one-tap'),
    ApiOperation({ summary: '微信一键登录（手机号校验 + openid）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [WechatOneTapDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "wechatOneTap", null);
__decorate([
    Post('admin/login'),
    ApiOperation({ summary: '管理员登录（账号+密码）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [LoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "adminLogin", null);
__decorate([
    Post('admin/update-nickname'),
    ApiOperation({ summary: '管理员修改昵称' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [UpdateNicknameDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "updateAdminNickname", null);
__decorate([
    Post('admin/update-password'),
    ApiOperation({ summary: '管理员修改密码' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [UpdatePasswordDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "updateAdminPassword", null);
AuthController = __decorate([
    ApiTags('auth'),
    Controller('auth'),
    __metadata("design:paramtypes", [AuthService])
], AuthController);
export { AuthController };
