var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { AdminRoleService } from './role.service.js';
import { AdminGuard } from './admin.guard.js';
import { RequirePerm } from './perm.decorator.js';
let AdminRoleController = class AdminRoleController {
    constructor(service) {
        this.service = service;
    }
    // 角色管理
    listRoles() { return this.service.listRoles(); }
    createRole(body) { return this.service.createRole(body); }
    updateRole(id, body) {
        return this.service.updateRole(Number(id), body);
    }
    removeRole(id) { return this.service.removeRole(Number(id)); }
    // 管理员管理
    listAdmins() { return this.service.listAdmins(); }
    createAdmin(body) { return this.service.createAdmin(body); }
    updateAdmin(id, body) {
        return this.service.updateAdmin(Number(id), body);
    }
    removeAdmin(id) { return this.service.removeAdmin(Number(id)); }
    // 菜单清单
    listMenus() { return this.service.listMenus(); }
};
__decorate([
    Get('roles'),
    ApiOperation({ summary: '角色列表' }),
    RequirePerm('system-roles'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "listRoles", null);
__decorate([
    Post('roles'),
    ApiOperation({ summary: '创建角色' }),
    RequirePerm('system-roles'),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "createRole", null);
__decorate([
    Put('roles/:id'),
    ApiOperation({ summary: '更新角色' }),
    RequirePerm('system-roles'),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "updateRole", null);
__decorate([
    Delete('roles/:id'),
    ApiOperation({ summary: '删除角色' }),
    RequirePerm('system-roles'),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "removeRole", null);
__decorate([
    Get('admins'),
    ApiOperation({ summary: '管理员列表' }),
    RequirePerm('system-admins'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "listAdmins", null);
__decorate([
    Post('admins'),
    ApiOperation({ summary: '创建管理员' }),
    RequirePerm('system-admins'),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "createAdmin", null);
__decorate([
    Put('admins/:id'),
    ApiOperation({ summary: '更新管理员' }),
    RequirePerm('system-admins'),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "updateAdmin", null);
__decorate([
    Delete('admins/:id'),
    ApiOperation({ summary: '删除管理员' }),
    RequirePerm('system-admins'),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "removeAdmin", null);
__decorate([
    Get('menus'),
    ApiOperation({ summary: '系统菜单清单' }),
    RequirePerm('system-roles'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AdminRoleController.prototype, "listMenus", null);
AdminRoleController = __decorate([
    ApiTags('system'),
    Controller('system'),
    UseGuards(AdminGuard),
    __metadata("design:paramtypes", [AdminRoleService])
], AdminRoleController);
export { AdminRoleController };
