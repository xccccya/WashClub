var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
let ScrollNoticeService = class ScrollNoticeService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    list(type) {
        return this.prisma.scrollNotice.findMany({
            where: type ? { type } : undefined,
            orderBy: [{ type: 'asc' }, { id: 'asc' }],
        });
    }
    async create(data) {
        const enabled = !!data.enabled;
        return this.prisma.$transaction(async (tx) => {
            if (enabled) {
                await tx.scrollNotice.updateMany({ where: { type: data.type, enabled: true }, data: { enabled: false } });
            }
            return tx.scrollNotice.create({ data: { type: data.type, content: data.content, enabled } });
        });
    }
    async update(id, data) {
        const notice = await this.prisma.scrollNotice.findUnique({ where: { id } });
        if (!notice)
            throw new NotFoundException('通知不存在');
        return this.prisma.$transaction(async (tx) => {
            if (data.enabled === true) {
                await tx.scrollNotice.updateMany({ where: { type: notice.type, enabled: true }, data: { enabled: false } });
            }
            return tx.scrollNotice.update({ where: { id }, data });
        });
    }
    remove(id) {
        return this.prisma.scrollNotice.delete({ where: { id } });
    }
    async enable(id) {
        const notice = await this.prisma.scrollNotice.findUnique({ where: { id } });
        if (!notice)
            throw new NotFoundException('通知不存在');
        return this.prisma.$transaction(async (tx) => {
            await tx.scrollNotice.updateMany({ where: { type: notice.type, enabled: true }, data: { enabled: false } });
            return tx.scrollNotice.update({ where: { id }, data: { enabled: true } });
        });
    }
    async getActive(type) {
        return this.prisma.scrollNotice.findFirst({ where: { type, enabled: true }, orderBy: { id: 'desc' } });
    }
};
ScrollNoticeService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService])
], ScrollNoticeService);
export { ScrollNoticeService };
