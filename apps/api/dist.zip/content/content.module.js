var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
import { ScrollNoticeService } from './scroll-notice.service.js';
import { ScrollNoticeController } from './scroll-notice.controller.js';
import { CarDataController } from './car-data.controller.js';
import { WeatherController } from './weather.controller.js';
import { DistrictController } from './district.controller.js';
import { AdBannerService } from './ad-banner.service.js';
import { AdBannerController } from './ad-banner.controller.js';
let ContentModule = class ContentModule {
};
ContentModule = __decorate([
    Module({
        imports: [],
        controllers: [ScrollNoticeController, CarDataController, WeatherController, AdBannerController, DistrictController],
        providers: [PrismaService, ScrollNoticeService, AdBannerService],
    })
], ContentModule);
export { ContentModule };
