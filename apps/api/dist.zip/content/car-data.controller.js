var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var CarDataController_1;
import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
let CarDataController = CarDataController_1 = class CarDataController {
    constructor() {
        this.apiKey = process.env.TANSHU_CAR_API_KEY || process.env.CAR_API_KEY || '';
    }
    async fetchJson(url, timeoutMs = 8000) {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
            const resp = await fetch(url, { signal: ctrl.signal });
            return await resp.json().catch(() => ({}));
        }
        finally {
            clearTimeout(timer);
        }
    }
    async getBrands() {
        const now = Date.now();
        if (CarDataController_1.brandsCache.data.length && now - CarDataController_1.brandsCache.ts < CarDataController_1.BRANDS_TTL_MS) {
            return CarDataController_1.brandsCache.data;
        }
        const url = `https://api.tanshuapi.com/api/car/v1/carBrand?key=${this.apiKey}`;
        try {
            const json = await this.fetchJson(url, 8000);
            const data = Array.isArray(json?.data) ? json.data : [];
            if (data.length)
                CarDataController_1.brandsCache = { data, ts: now };
            return data;
        }
        catch (e) {
            // 返回缓存兜底，避免 5xx
            return CarDataController_1.brandsCache.data || [];
        }
    }
    async getSeries(brandId) {
        const id = Number(brandId);
        if (!id)
            return [];
        const now = Date.now();
        const cached = CarDataController_1.seriesCache.get(id);
        if (cached && now - cached.ts < CarDataController_1.SERIES_TTL_MS)
            return cached.data;
        const url = `https://api.tanshuapi.com/api/car/v1/carSeries?brand_id=${id}&key=${this.apiKey}`;
        try {
            const json = await this.fetchJson(url, 8000);
            const data = Array.isArray(json?.data) ? json.data : [];
            if (data.length)
                CarDataController_1.seriesCache.set(id, { data, ts: now });
            return data;
        }
        catch (e) {
            return cached?.data || [];
        }
    }
};
CarDataController.brandsCache = { data: [], ts: 0 };
CarDataController.seriesCache = new Map();
CarDataController.BRANDS_TTL_MS = 24 * 60 * 60 * 1000; // 24h
CarDataController.SERIES_TTL_MS = 24 * 60 * 60 * 1000; // 24h
__decorate([
    Get('brands'),
    ApiOperation({ summary: '车型品牌列表（含缓存）' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CarDataController.prototype, "getBrands", null);
__decorate([
    Get('series'),
    ApiOperation({ summary: '车型车系列表（按品牌，含缓存）' }),
    __param(0, Query('brandId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CarDataController.prototype, "getSeries", null);
CarDataController = CarDataController_1 = __decorate([
    ApiTags('content'),
    Controller('content/car')
], CarDataController);
export { CarDataController };
