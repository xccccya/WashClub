var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, Post, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { AdBannerService } from './ad-banner.service.js';
let AdBannerController = class AdBannerController {
    constructor(service) {
        this.service = service;
    }
    // 管理端：列表，可按启用状态筛选
    list(enabled) { return this.service.list(enabled); }
    // 管理端：创建
    create(body) { return this.service.create(body); }
    // 管理端：更新
    update(id, body) { return this.service.update(Number(id), body); }
    // 管理端：删除
    remove(id) { return this.service.remove(Number(id)); }
    // 管理端：启用/禁用
    setEnable(id, enabled) { return this.service.enable(Number(id), String(enabled) !== 'false'); }
    // 小程序端：获取已启用列表
    active() { return this.service.activeList(); }
};
__decorate([
    Get('banners'),
    ApiOperation({ summary: '广告位列表（可按启用状态筛选）' }),
    __param(0, Query('enabled')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "list", null);
__decorate([
    Post('banners'),
    ApiOperation({ summary: '创建广告位' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "create", null);
__decorate([
    Put('banners/:id'),
    ApiOperation({ summary: '更新广告位' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "update", null);
__decorate([
    Delete('banners/:id'),
    ApiOperation({ summary: '删除广告位' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "remove", null);
__decorate([
    Post('banners/:id/enable'),
    ApiOperation({ summary: '启用/禁用广告位' }),
    __param(0, Param('id')),
    __param(1, Body('enabled')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "setEnable", null);
__decorate([
    Get('banners/active'),
    ApiOperation({ summary: '小程序端：获取已启用广告位列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AdBannerController.prototype, "active", null);
AdBannerController = __decorate([
    ApiTags('content'),
    Controller('content'),
    __metadata("design:paramtypes", [AdBannerService])
], AdBannerController);
export { AdBannerController };
