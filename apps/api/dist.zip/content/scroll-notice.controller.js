var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, Post, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { ScrollNoticeService } from './scroll-notice.service.js';
let ScrollNoticeController = class ScrollNoticeController {
    constructor(service) {
        this.service = service;
    }
    // 管理端：列表
    list(type) { return this.service.list(type); }
    // 管理端：创建
    create(body) { return this.service.create(body); }
    // 管理端：更新
    update(id, body) { return this.service.update(Number(id), body); }
    // 管理端：删除
    remove(id) { return this.service.remove(Number(id)); }
    // 管理端：启用指定公告（会自动禁用同类型其他）
    enable(id) { return this.service.enable(Number(id)); }
    // 小程序端：获取某类型当前启用公告
    active(type) { return this.service.getActive(type); }
};
__decorate([
    Get('notices'),
    ApiOperation({ summary: '滚动公告列表（可按类型筛选）' }),
    __param(0, Query('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "list", null);
__decorate([
    Post('notices'),
    ApiOperation({ summary: '创建滚动公告' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "create", null);
__decorate([
    Put('notices/:id'),
    ApiOperation({ summary: '更新滚动公告' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "update", null);
__decorate([
    Delete('notices/:id'),
    ApiOperation({ summary: '删除滚动公告' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "remove", null);
__decorate([
    Post('notices/:id/enable'),
    ApiOperation({ summary: '启用指定公告（自动禁用同类型其他）' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "enable", null);
__decorate([
    Get('notices/active'),
    ApiOperation({ summary: '小程序端：获取某类型当前启用公告' }),
    __param(0, Query('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ScrollNoticeController.prototype, "active", null);
ScrollNoticeController = __decorate([
    ApiTags('content'),
    Controller('content'),
    __metadata("design:paramtypes", [ScrollNoticeService])
], ScrollNoticeController);
export { ScrollNoticeController };
