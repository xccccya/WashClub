var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
let DistrictController = class DistrictController {
    async getDistrict(keywords, subdistrict, extensions, level) {
        const key = process.env.AMAP_KEY || process.env.AMAP_WEB_KEY;
        if (!key)
            throw new BadRequestException('Missing AMAP_KEY');
        const baseUrl = 'https://restapi.amap.com/v3/config/district';
        const toQS = (params) => Object.entries(params)
            .filter(([, v]) => typeof v !== 'undefined' && v !== null && String(v).length > 0)
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
            .join('&');
        const url = `${baseUrl}?${toQS({
            key,
            keywords: (keywords || '').trim(),
            subdistrict: (subdistrict || '').trim(),
            extensions: (extensions || '').trim(),
            level: (level || '').trim(),
        })}`;
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 8000);
        try {
            const res = await fetch(url, { signal: ctrl.signal });
            clearTimeout(timer);
            if (!res.ok)
                throw new Error(`HTTP ${res.status}`);
            const json = (await res.json());
            return json;
        }
        catch (e) {
            clearTimeout(timer);
            return { status: '0', info: 'network_or_proxy', infocode: '0', error: e?.message || 'failed' };
        }
    }
};
__decorate([
    Get('district'),
    ApiOperation({ summary: '行政区查询（代理高德API）' }),
    __param(0, Query('keywords')),
    __param(1, Query('subdistrict')),
    __param(2, Query('extensions')),
    __param(3, Query('level')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], DistrictController.prototype, "getDistrict", null);
DistrictController = __decorate([
    ApiTags('content'),
    Controller('content')
], DistrictController);
export { DistrictController };
