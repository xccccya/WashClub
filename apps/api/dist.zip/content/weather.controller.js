var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
let WeatherController = class WeatherController {
    async getWeather(city) {
        const adcode = (city || '511024').trim();
        const key = process.env.AMAP_KEY || process.env.AMAP_WEB_KEY;
        if (!key)
            throw new BadRequestException('Missing AMAP_KEY');
        const baseUrl = 'https://restapi.amap.com/v3/weather/weatherInfo';
        const toQS = (params) => Object.entries(params)
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
            .join('&');
        async function fetchJson(url, timeoutMs = 6000, retries = 1) {
            let lastErr = null;
            for (let attempt = 0; attempt <= retries; attempt++) {
                const ctrl = new AbortController();
                const timer = setTimeout(() => ctrl.abort(), timeoutMs);
                try {
                    const res = await fetch(url, { signal: ctrl.signal });
                    clearTimeout(timer);
                    if (!res.ok)
                        throw new Error(`HTTP ${res.status}`);
                    return await res.json();
                }
                catch (e) {
                    lastErr = e;
                    clearTimeout(timer);
                    // 小退避
                    await new Promise((r) => setTimeout(r, 200));
                }
            }
            throw lastErr ?? new Error('fetch failed');
        }
        const liveUrl = `${baseUrl}?${toQS({ city: adcode, key, extensions: 'base' })}`;
        const forecastUrl = `${baseUrl}?${toQS({ city: adcode, key, extensions: 'all' })}`;
        const [liveSettled, forecastSettled] = await Promise.allSettled([
            fetchJson(liveUrl, 6000, 1),
            fetchJson(forecastUrl, 6000, 1),
        ]);
        const liveRes = liveSettled.status === 'fulfilled' ? liveSettled.value : null;
        const forecastRes = forecastSettled.status === 'fulfilled' ? forecastSettled.value : null;
        const liveOk = liveRes && liveRes.infocode === '10000';
        const forecastOk = forecastRes && forecastRes.infocode === '10000';
        if (!liveOk && !forecastOk) {
            return {
                ok: false,
                source: 'amap',
                adcode,
                cityLabel: adcode === '511024' ? '威远县' : '',
                error: 'network_or_proxy',
                message: '服务器访问高德天气失败，可能是网络、代理或 TLS 受限',
            };
        }
        const live = liveOk && Array.isArray(liveRes?.lives) && liveRes.lives.length > 0 ? liveRes.lives[0] : null;
        const forecast = forecastOk && Array.isArray(forecastRes?.forecasts) && forecastRes.forecasts.length > 0 ? forecastRes.forecasts[0] : null;
        return {
            ok: true,
            source: 'amap',
            adcode,
            cityName: live?.city || forecast?.city || '',
            province: live?.province || forecast?.province || '',
            reporttimeLive: live?.reporttime || null,
            reporttimeForecast: forecast?.reporttime || null,
            cityLabel: adcode === '511024' ? '威远县' : live?.city || forecast?.city || '',
            live,
            forecast,
            partial: { live: !!live, forecast: !!forecast },
        };
    }
};
__decorate([
    Get('weather'),
    ApiOperation({ summary: '天气：实时与预报（高德API）' }),
    __param(0, Query('city')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], WeatherController.prototype, "getWeather", null);
WeatherController = __decorate([
    ApiTags('content'),
    Controller('content')
], WeatherController);
export { WeatherController };
