var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
let AdBannerService = class AdBannerService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    list(enabled) {
        const where = typeof enabled === 'string' && enabled !== '' ? { enabled: enabled === 'true' } : undefined;
        return this.prisma.adBanner.findMany({
            where,
            orderBy: [{ weight: 'desc' }, { id: 'desc' }],
        });
    }
    create(data) {
        return this.prisma.adBanner.create({ data: {
                title: data.title ?? null,
                imageUrl: data.imageUrl,
                enabled: !!data.enabled,
                jumpEnabled: !!data.jumpEnabled,
                linkPath: data.linkPath ?? null,
                weight: Number.isFinite(data.weight) ? Number(data.weight) : 0,
            } });
    }
    async update(id, data) {
        const exists = await this.prisma.adBanner.findUnique({ where: { id } });
        if (!exists)
            throw new NotFoundException('横幅不存在');
        return this.prisma.adBanner.update({ where: { id }, data: {
                title: data.title === undefined ? exists.title : (data.title ?? null),
                imageUrl: data.imageUrl ?? exists.imageUrl,
                enabled: data.enabled ?? exists.enabled,
                jumpEnabled: data.jumpEnabled ?? exists.jumpEnabled,
                linkPath: data.linkPath === undefined ? exists.linkPath : (data.linkPath ?? null),
                weight: data.weight === undefined ? exists.weight : Number(data.weight || 0),
            } });
    }
    remove(id) {
        return this.prisma.adBanner.delete({ where: { id } });
    }
    async enable(id, enabled) {
        const exists = await this.prisma.adBanner.findUnique({ where: { id } });
        if (!exists)
            throw new NotFoundException('横幅不存在');
        if (enabled) {
            const cnt = await this.prisma.adBanner.count({ where: { enabled: true } });
            if (cnt >= 3) {
                throw new Error('最多可同时启用3条横幅');
            }
        }
        return this.prisma.adBanner.update({ where: { id }, data: { enabled } });
    }
    activeList() {
        return this.prisma.adBanner.findMany({ where: { enabled: true }, orderBy: [{ weight: 'desc' }, { id: 'desc' }], take: 3 });
    }
};
AdBannerService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService])
], AdBannerService);
export { AdBannerService };
