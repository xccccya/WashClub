var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { QueueService } from './queue.service.js';
let QueueController = class QueueController {
    constructor(service) {
        this.service = service;
    }
    list() { return this.service.listActive(); }
    summary() { return this.service.summary(); }
    add(body) {
        const mode = String(body?.mode || '').trim();
        if (!mode)
            throw new BadRequestException('缺少添加方式');
        if (mode === 'vehicleId')
            return this.service.addToQueue({ mode: 'vehicleId', vehicleId: Number(body.vehicleId) });
        if (mode === 'plateExisting')
            return this.service.addToQueue({ mode: 'plateExisting', plateNumber: String(body.plateNumber || '').trim() });
        if (mode === 'guest') {
            return this.service.addToQueue({
                mode: 'guest',
                plateNumber: String(body.plateNumber || '').trim(),
                vin: body.vin,
                typeMain: body.typeMain,
                typeSub: body.typeSub,
                color: body.color,
                brand: body.brand,
                series: body.series,
                brandId: typeof body.brandId === 'number' ? body.brandId : (body.brandId ? Number(body.brandId) : undefined),
                seriesId: typeof body.seriesId === 'number' ? body.seriesId : (body.seriesId ? Number(body.seriesId) : undefined),
            });
        }
        throw new BadRequestException('不支持的添加方式');
    }
    setCurrent(id, body) {
        if (typeof body?.taskIndex !== 'number')
            throw new BadRequestException('taskIndex 必须为数字');
        return this.service.setCurrentTask(Number(id), Number(body.taskIndex));
    }
    finishTask(id) { return this.service.finishCurrentTask(Number(id)); }
    confirmComplete(id) { return this.service.confirmComplete(Number(id)); }
    startFirst(id) { return this.service.startFirstTask(Number(id)); }
    remove(id) { return this.service.remove(Number(id)); }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '服务队列列表（进行中/待处理）' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "list", null);
__decorate([
    Get('summary'),
    ApiOperation({ summary: '队列摘要统计' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "summary", null);
__decorate([
    Post('add'),
    ApiOperation({ summary: '添加到队列（支持多种模式）' }),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "add", null);
__decorate([
    Post(':id/set-current'),
    ApiOperation({ summary: '设置当前执行任务索引' }),
    __param(0, Param('id')),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "setCurrent", null);
__decorate([
    Post(':id/finish-task'),
    ApiOperation({ summary: '完成当前任务节点' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "finishTask", null);
__decorate([
    Post(':id/confirm-complete'),
    ApiOperation({ summary: '确认整单已完成' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "confirmComplete", null);
__decorate([
    Post(':id/start-first'),
    ApiOperation({ summary: '开始第一步任务' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "startFirst", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '移出队列/取消' }),
    __param(0, Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], QueueController.prototype, "remove", null);
QueueController = __decorate([
    ApiTags('queue'),
    Controller('queue'),
    __metadata("design:paramtypes", [QueueService])
], QueueController);
export { QueueController };
