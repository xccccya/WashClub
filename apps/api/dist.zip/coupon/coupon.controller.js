var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query, UseGuards } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CouponService } from './coupon.service.js';
import { AdminGuard } from '../auth/admin.guard.js';
import { RequirePerm } from '../auth/perm.decorator.js';
let CouponController = class CouponController {
    constructor(svc) {
        this.svc = svc;
    }
    list(groupIdStr, type, enabledStr) {
        const groupId = groupIdStr !== undefined ? Number(groupIdStr) : undefined;
        const enabled = enabledStr !== undefined ? enabledStr === 'true' : undefined;
        return this.svc.listCoupons({ groupId, type: type || null, enabled: enabled });
    }
    get(id) { return this.svc.getCoupon(id); }
    create(body) { return this.svc.createCoupon(body); }
    update(id, body) { return this.svc.updateCoupon(id, body); }
    remove(id) { return this.svc.deleteCoupon(id); }
    // 发放给指定会员
    issue(id, body) {
        return this.svc.issueToMember({ couponId: id, memberId: Number(body.memberId), count: Number(body?.count || 1) });
    }
};
__decorate([
    Get(''),
    ApiOperation({ summary: '卡券列表' }),
    RequirePerm('coupons'),
    __param(0, Query('groupId')),
    __param(1, Query('type')),
    __param(2, Query('enabled')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "list", null);
__decorate([
    Get(':id'),
    ApiOperation({ summary: '卡券详情' }),
    RequirePerm('coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "get", null);
__decorate([
    Post(''),
    ApiOperation({ summary: '创建卡券' }),
    RequirePerm('coupons'),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "create", null);
__decorate([
    Put(':id'),
    ApiOperation({ summary: '更新卡券' }),
    RequirePerm('coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "update", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除卡券' }),
    RequirePerm('coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "remove", null);
__decorate([
    Post(':id/issue'),
    ApiOperation({ summary: '发放优惠券到指定会员' }),
    RequirePerm('coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], CouponController.prototype, "issue", null);
CouponController = __decorate([
    ApiTags('Coupon'),
    Controller('coupons'),
    UseGuards(AdminGuard),
    __metadata("design:paramtypes", [CouponService])
], CouponController);
export { CouponController };
