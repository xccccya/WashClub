var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, ParseIntPipe, Put, Query, UseGuards } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CouponService } from './coupon.service.js';
import { AdminGuard } from '../auth/admin.guard.js';
import { RequirePerm } from '../auth/perm.decorator.js';
let MemberCouponAdminController = class MemberCouponAdminController {
    constructor(svc) {
        this.svc = svc;
    }
    list(page, pageSize, memberId, couponId, used, expired) {
        return this.svc.listMemberCoupons({ page: Number(page || 1), pageSize: Number(pageSize || 20), memberId: memberId ? Number(memberId) : null, couponId: couponId ? Number(couponId) : null, used: used ?? null, expired: expired ?? null });
    }
    get(id) { return this.svc.getMemberCoupon(id); }
    updateExpiry(id, body) {
        const payload = {};
        if ('startAt' in (body || {}))
            payload.startAt = body.startAt ? new Date(body.startAt) : null;
        if ('endAt' in (body || {}))
            payload.endAt = body.endAt ? new Date(body.endAt) : null;
        return this.svc.updateMemberCouponExpiry(id, payload);
    }
    remove(id) { return this.svc.deleteMemberCoupon(id); }
};
__decorate([
    Get(''),
    ApiOperation({ summary: '会员优惠券实例列表' }),
    RequirePerm('member-coupons'),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('memberId')),
    __param(3, Query('couponId')),
    __param(4, Query('used')),
    __param(5, Query('expired')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MemberCouponAdminController.prototype, "list", null);
__decorate([
    Get(':id'),
    ApiOperation({ summary: '会员优惠券详情' }),
    RequirePerm('member-coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], MemberCouponAdminController.prototype, "get", null);
__decorate([
    Put(':id/expiry'),
    ApiOperation({ summary: '修改有效期（开始/结束时间）' }),
    RequirePerm('member-coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], MemberCouponAdminController.prototype, "updateExpiry", null);
__decorate([
    Delete(':id'),
    ApiOperation({ summary: '删除会员优惠券实例' }),
    RequirePerm('member-coupons'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], MemberCouponAdminController.prototype, "remove", null);
MemberCouponAdminController = __decorate([
    ApiTags('MemberCoupons'),
    Controller('member-coupons'),
    UseGuards(AdminGuard),
    __metadata("design:paramtypes", [CouponService])
], MemberCouponAdminController);
export { MemberCouponAdminController };
