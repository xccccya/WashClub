var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable, BadRequestException } from '@nestjs/common';
import { writeFileSync, existsSync, mkdirSync, statSync, readdirSync, unlinkSync } from 'node:fs';
import { extname, join, normalize, sep } from 'node:path';
let FileService = class FileService {
    getUploadsRoot() { return join(process.cwd(), 'uploads'); }
    ensureDir(dir) {
        if (!existsSync(dir))
            mkdirSync(dir, { recursive: true });
    }
    safeJoin(root, targetRel) {
        const p = normalize(join(root, targetRel));
        if (!p.startsWith(root))
            throw new BadRequestException('非法路径');
        return p;
    }
    saveFile(buffer, originalName, dir) {
        const root = this.getUploadsRoot();
        const now = new Date();
        const sub = join(dir || 'public', String(now.getFullYear()), String(now.getMonth() + 1).padStart(2, '0'));
        const targetDir = this.safeJoin(root, sub);
        this.ensureDir(targetDir);
        const ext = extname(originalName || '').toLowerCase();
        const rnd = Math.random().toString(36).slice(2, 10);
        const filenameOnly = `${now.getTime()}_${rnd}${ext || ''}`;
        const abs = join(targetDir, filenameOnly);
        writeFileSync(abs, buffer);
        const relPath = [sub, filenameOnly].join(sep).split('\\').join('/');
        const size = statSync(abs).size;
        return { filename: filenameOnly, url: `/uploads/${relPath}`, path: relPath, size };
    }
    list(dir = 'public') {
        const root = this.getUploadsRoot();
        const target = this.safeJoin(root, dir);
        this.ensureDir(target);
        const results = [];
        const walk = (d, prefixRel) => {
            for (const name of readdirSync(d)) {
                const abs = join(d, name);
                const st = statSync(abs);
                if (st.isDirectory())
                    walk(abs, `${prefixRel}${name}/`);
                else
                    results.push({ name, url: `/uploads/${prefixRel}${name}`, path: `${prefixRel}${name}`, size: st.size, mtime: st.mtimeMs });
            }
        };
        walk(target, (dir.endsWith('/') ? dir : dir + '/').replace(/^\/+/, ''));
        return results.sort((a, b) => b.mtime - a.mtime);
    }
    remove(pathRel) {
        const root = this.getUploadsRoot();
        const abs = this.safeJoin(root, pathRel);
        if (!existsSync(abs))
            return { ok: true };
        unlinkSync(abs);
        return { ok: true };
    }
};
FileService = __decorate([
    Injectable()
], FileService);
export { FileService };
