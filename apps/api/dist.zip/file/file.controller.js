var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { BadRequestException, Body, Controller, Delete, Get, Param, Post, UploadedFile, UseInterceptors, Query } from '@nestjs/common';
import { ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { FileService } from './file.service.js';
import multer from 'multer';
let FileController = class FileController {
    constructor(service) {
        this.service = service;
    }
    list(dir) { return this.service.list(dir || 'public'); }
    upload(file, dir) {
        if (!file?.buffer || !file?.originalname)
            throw new BadRequestException('未接收到文件');
        const saved = this.service.saveFile(file.buffer, file.originalname, dir || 'public');
        return saved;
    }
    remove(path) { return this.service.remove(decodeURIComponent(path)); }
};
__decorate([
    Get('list'),
    ApiOperation({ summary: '列出指定目录下的文件（默认public）' }),
    __param(0, Query('dir')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FileController.prototype, "list", null);
__decorate([
    Post('upload'),
    UseInterceptors(FileInterceptor('file', { storage: multer.memoryStorage() })),
    ApiConsumes('multipart/form-data'),
    ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' }, dir: { type: 'string' } } } }),
    ApiOperation({ summary: '上传文件到指定目录（默认public）' }),
    __param(0, UploadedFile()),
    __param(1, Body('dir')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], FileController.prototype, "upload", null);
__decorate([
    Delete(':path'),
    ApiOperation({ summary: '删除指定路径文件' }),
    __param(0, Param('path')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FileController.prototype, "remove", null);
FileController = __decorate([
    ApiTags('file'),
    Controller('file'),
    __metadata("design:paramtypes", [FileService])
], FileController);
export { FileController };
