var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
let PrismaService = class PrismaService extends PrismaClient {
    async onModuleInit() {
        await this.$connect();
        // 统一数据库会话的时区为 UTC+8（Asia/Shanghai）
        try {
            // 会话级别设置，避免依赖数据库全局配置
            await this.$executeRawUnsafe("SET time_zone = '+08:00'");
        }
        catch (error) {
            // eslint-disable-next-line no-console
            console.warn('[Prisma] SET time_zone +08:00 失败：', error);
        }
    }
    async enableShutdownHooks(app) {
        // @ts-expect-error Prisma types
        this.$on('beforeExit', async () => {
            await app.close();
        });
    }
};
PrismaService = __decorate([
    Injectable()
], PrismaService);
export { PrismaService };
