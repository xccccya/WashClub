var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
import { StoreService } from './store.service.js';
import { StoreCategoryController } from './category.controller.js';
import { StoreProductController } from './product.controller.js';
import { StoreInventoryController } from './inventory.controller.js';
import { FileService } from '../file/file.service.js';
let StoreModule = class StoreModule {
};
StoreModule = __decorate([
    Module({
        imports: [
            JwtModule.register({
                secret: process.env.JWT_SECRET || 'dev_secret',
            }),
        ],
        controllers: [StoreCategoryController, StoreProductController, StoreInventoryController],
        providers: [PrismaService, StoreService, FileService],
    })
], StoreModule);
export { StoreModule };
