var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Get, Post, Query, Headers } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { StoreService } from './store.service.js';
import { JwtService } from '@nestjs/jwt';
let StoreInventoryController = class StoreInventoryController {
    constructor(store, jwt) {
        this.store = store;
        this.jwt = jwt;
    }
    adjust(body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.store.adjustInventory({ ...body, operatorUserId });
    }
    logs(productId, skuId, reason, page, pageSize) {
        return this.store.listInventoryLogs({
            productId: productId ? Number(productId) : undefined,
            skuId: skuId ? Number(skuId) : undefined,
            reason: reason || undefined,
            page: page ? Number(page) : undefined,
            pageSize: pageSize ? Number(pageSize) : undefined,
        });
    }
    extractAdminIdFromAuthHeader(authHeader) {
        if (!authHeader)
            return undefined;
        const m = /^Bearer\s+(.+)$/.exec(authHeader);
        const token = m?.[1];
        if (!token)
            return undefined;
        try {
            const decoded = this.jwt.verify(token);
            if (decoded?.type !== 'admin')
                return undefined;
            const id = Number(decoded?.sub);
            return Number.isFinite(id) && id > 0 ? id : undefined;
        }
        catch {
            // 忽略非法token，按匿名处理
            return undefined;
        }
    }
};
__decorate([
    Post('adjust'),
    __param(0, Body()),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], StoreInventoryController.prototype, "adjust", null);
__decorate([
    Get('logs'),
    __param(0, Query('productId')),
    __param(1, Query('skuId')),
    __param(2, Query('reason')),
    __param(3, Query('page')),
    __param(4, Query('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], StoreInventoryController.prototype, "logs", null);
StoreInventoryController = __decorate([
    ApiTags('StoreInventory'),
    Controller('store/inventory'),
    __metadata("design:paramtypes", [StoreService, JwtService])
], StoreInventoryController);
export { StoreInventoryController };
