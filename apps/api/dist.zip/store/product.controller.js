var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { StoreService } from './store.service.js';
import { FileService } from '../file/file.service.js';
let StoreProductController = class StoreProductController {
    constructor(store, files) {
        this.store = store;
        this.files = files;
    }
    list(keyword, categoryIdStr, type, enabledStr) {
        const categoryId = categoryIdStr !== undefined ? Number(categoryIdStr) : undefined;
        const enabled = enabledStr !== undefined ? enabledStr === 'true' : undefined;
        return this.store.listProducts({ keyword, categoryId, type, enabled });
    }
    get(id) { return this.store.getProduct(id); }
    create(body) { return this.store.createProduct(body); }
    update(id, body) { return this.store.updateProduct(id, body); }
    remove(id) { return this.store.deleteProduct(id); }
    // 复用已有文件上传用于商品图片
    async uploadImage() {
        // 控制器层仅占位，文件上传由全局 /file/upload 提供
        return { message: '请使用 /file/upload 上传文件后，将返回的 url 保存到 product.imageUrl 或 sku.imageUrl' };
    }
};
__decorate([
    Get(''),
    __param(0, Query('keyword')),
    __param(1, Query('categoryId')),
    __param(2, Query('type')),
    __param(3, Query('enabled')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], StoreProductController.prototype, "list", null);
__decorate([
    Get(':id'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], StoreProductController.prototype, "get", null);
__decorate([
    Post(''),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], StoreProductController.prototype, "create", null);
__decorate([
    Put(':id'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], StoreProductController.prototype, "update", null);
__decorate([
    Delete(':id'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], StoreProductController.prototype, "remove", null);
__decorate([
    Post(':id/upload-image'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StoreProductController.prototype, "uploadImage", null);
StoreProductController = __decorate([
    ApiTags('StoreProduct'),
    Controller('store/products'),
    __metadata("design:paramtypes", [StoreService, FileService])
], StoreProductController);
export { StoreProductController };
