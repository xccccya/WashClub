var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaService } from './prisma.service.js';
import { AppController } from './app.controller.js';
import { AuthModule } from './auth/auth.module.js';
import { MemberModule } from './member/member.module.js';
import { FileController } from './file/file.controller.js';
import { FileService } from './file/file.service.js';
import { ContentModule } from './content/content.module.js';
import { QueueModule } from './queue/queue.module.js';
import { StoreModule } from './store/store.module.js';
import { OrderModule } from './order/order.module.js';
import { CouponModule } from './coupon/coupon.module.js';
let AppModule = class AppModule {
};
AppModule = __decorate([
    Module({
        imports: [ConfigModule.forRoot({ isGlobal: true, envFilePath: ['.env', 'apps/api/.env', 'apps/api/prisma/.env'] }), AuthModule, MemberModule, ContentModule, QueueModule, StoreModule, OrderModule, CouponModule],
        controllers: [AppController, FileController],
        providers: [PrismaService, FileService],
    })
], AppModule);
export { AppModule };
