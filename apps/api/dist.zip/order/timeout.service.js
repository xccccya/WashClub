var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
import { WxpayService } from './wxpay.service.js';
let OrderTimeoutService = class OrderTimeoutService {
    constructor(prisma, wxpay) {
        this.prisma = prisma;
        this.wxpay = wxpay;
        this.logger = new Logger('OrderTimeoutService');
        this.timer = null;
    }
    onModuleInit() {
        const enabled = String(process.env.ORDER_TIMEOUT_ENABLED || 'true').toLowerCase() !== 'false';
        const intervalMs = Number(process.env.ORDER_TIMEOUT_SCAN_MS || 60000);
        if (!enabled) {
            this.logger.log('Order timeout scanner disabled by env');
            return;
        }
        this.timer = setInterval(() => this.scanAndCancelExpired().catch(() => { }), Math.max(intervalMs, 10000));
        this.logger.log(`Order timeout scanner started (interval=${Math.max(intervalMs, 10000)}ms)`);
    }
    onModuleDestroy() {
        if (this.timer) {
            try {
                clearInterval(this.timer);
            }
            catch { }
            this.timer = null;
        }
    }
    async scanAndCancelExpired() {
        // 超时时间：15分钟
        const now = Date.now();
        const threshold = new Date(now - 15 * 60 * 1000);
        const candidates = await this.prisma.order.findMany({
            where: { payStatus: 'UNPAID', deletedAt: null, createdAt: { lt: threshold } },
            take: 50, // 分批处理
            orderBy: { id: 'asc' }
        });
        for (const ord of candidates) {
            try {
                // 尝试关闭微信订单（幂等）
                try {
                    await this.wxpay.closeJsapi(ord.no);
                }
                catch { }
                // 执行统一取消逻辑（库存回滚仅针对已占用情况，这里为未支付大多不占用）
                await this.prisma.order.update({ where: { id: ord.id }, data: { status: 'CANCELLED', payStatus: 'CANCELLED', remark: '系统超时取消（15分钟未支付）' } });
                // 时间线
                try {
                    await this.prisma.orderTimeline.create({ data: { orderId: ord.id, event: 'ORDER_STATUS', value: 'CANCELLED', remark: 'TIMEOUT_15MIN', operatorUserId: null } });
                }
                catch { }
                try {
                    await this.prisma.orderTimeline.create({ data: { orderId: ord.id, event: 'PAY_STATUS', value: 'CANCELLED', remark: 'TIMEOUT_15MIN', operatorUserId: null } });
                }
                catch { }
            }
            catch (e) {
                this.logger.warn(`Auto-cancel failed for order ${ord.id}/${ord.no}: ${e?.message || e}`);
            }
        }
    }
};
OrderTimeoutService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [PrismaService, WxpayService])
], OrderTimeoutService);
export { OrderTimeoutService };
