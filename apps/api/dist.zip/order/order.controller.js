var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Body, Controller, Get, Param, ParseIntPipe, Post, Query, Headers, Req, Res, BadRequestException, UseGuards, UnauthorizedException } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { OrderService } from './order.service.js';
import { TanshuService } from './tanshu.service.js';
import { JwtService } from '@nestjs/jwt';
import { WxpayService } from './wxpay.service.js';
import { AdminGuard } from '../auth/admin.guard.js';
import { RequirePerm } from '../auth/perm.decorator.js';
let OrderController = class OrderController {
    constructor(orders, jwt, tanshu, wxpay) {
        this.orders = orders;
        this.jwt = jwt;
        this.tanshu = tanshu;
        this.wxpay = wxpay;
    }
    create(body) { return this.orders.createOrder(body); }
    get(id) { return this.orders.getOrder(id); }
    getByNo(no) { return this.orders.getOrderByNo(no); }
    async list(type, status, payStatus, scene, includeDeletedStr, memberIdStr, keyword, start, end, authHeader) {
        // 统一鉴权：支持 admin 与 member
        const token = /^Bearer\s+(.+)$/.exec(String(authHeader || ''))?.[1];
        if (!token)
            throw new UnauthorizedException('未登录');
        let decoded;
        try {
            decoded = this.jwt.verify(token);
        }
        catch {
            throw new UnauthorizedException('登录已过期');
        }
        const tokenType = String(decoded?.type || '');
        if (tokenType !== 'admin' && tokenType !== 'member')
            throw new UnauthorizedException('身份无效');
        let memberId = memberIdStr ? Number(memberIdStr) : undefined;
        let includeDeleted = String(includeDeletedStr || '').toLowerCase() === 'true';
        if (tokenType === 'member') {
            // 会员仅能查询自己的订单，且不可查看已删除
            const selfId = Number(decoded?.sub);
            memberId = Number.isFinite(selfId) ? selfId : undefined;
            includeDeleted = false;
        }
        return this.orders.listOrders({ type: type, status: status, payStatus: payStatus, scene, includeDeleted, memberId, keyword, start, end });
    }
    // 微信 JSAPI 预支付下单：返回 wx.requestPayment 所需参数
    async wechatJsapi(id, authHeader) {
        // 校验会员身份
        const memberId = this.extractMemberIdFromAuthHeader(authHeader);
        if (!memberId)
            throw new BadRequestException('未登录或身份无效');
        const order = await this.orders.getOrder(id);
        if (!order || order.memberId !== memberId)
            throw new BadRequestException('订单不存在或不属于当前用户');
        if (order.payStatus !== 'UNPAID')
            throw new BadRequestException('订单非待支付状态');
        // 获取 openid
        const openid = await this.orders.getMemberOpenId(memberId);
        if (!openid)
            throw new BadRequestException('当前账号未绑定微信openid，请使用一键登录后重试');
        // 元转分
        const amountYuan = Number(order.payAmount);
        if (!Number.isFinite(amountYuan) || amountYuan <= 0)
            throw new BadRequestException('订单金额异常');
        const total = Math.round(amountYuan * 100);
        const notifyUrl = (process.env.PUBLIC_API_BASE || '').replace(/\/$/, '') + '/orders/_notify/wechat';
        const desc = `订单支付-${order.no}`;
        const { prepay_id } = await this.wxpay.createJsapi({
            appid: '', // 由服务内部覆盖为小程序 appid
            mchid: '', // 由服务内部覆盖为商户号
            description: desc,
            out_trade_no: order.no,
            notify_url: notifyUrl || 'https://example.com/orders/_notify/wechat',
            amount: { total },
            payer: { openid },
            attach: JSON.stringify({ orderId: order.id })
        });
        const clientParams = this.wxpay.buildJsapiClientPayParams(prepay_id);
        return { ...clientParams };
    }
    // 微信支付回调（v3）
    async wechatNotify(req, res) {
        try {
            const body = req.body || {};
            // 验证签名由网关/中间件处理，这里直接解密 resource
            const resource = body?.resource || {};
            if (!resource?.nonce || !resource?.associated_data || !resource?.ciphertext)
                throw new BadRequestException('非法通知');
            const decrypted = this.wxpay.decryptNotifyResource(resource.nonce, resource.associated_data, resource.ciphertext);
            // 处理状态
            if (decrypted?.trade_state === 'SUCCESS') {
                const outTradeNo = decrypted?.out_trade_no;
                const order = await this.orders.getOrderByNo(outTradeNo);
                if (order && order.payStatus === 'UNPAID') {
                    await this.orders.markPaid({ orderId: order.id, method: 'WECHAT_JSAPI', paidAt: new Date() });
                }
            }
            res.status(200).json({ code: 'SUCCESS' });
        }
        catch (e) {
            res.status(500).json({ code: 'ERROR', message: e?.message || String(e) });
        }
    }
    markPaid(id, body, authHeader) {
        const paidAt = body.paidAt ? new Date(body.paidAt) : undefined;
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.markPaid({ orderId: id, method: body.method, paidAt, operatorUserId });
    }
    // 软删除（替换原“关闭”操作）：仅设置 deletedAt，不改其他状态
    close(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.softDeleteOrder(id, operatorUserId);
    }
    // 取消订单（未支付）：若为JSAPI下单过的订单，调用微信关单
    async cancelOrder(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        const order = await this.orders.getOrder(id);
        if (!order)
            throw new BadRequestException('订单不存在');
        if (order.payStatus !== 'UNPAID')
            throw new BadRequestException('仅未支付订单可取消');
        // 关单：按是否存在JSAPI预下单做兜底，这里直接调用关单接口（多次调用幂等）
        try {
            await this.wxpay.closeJsapi(order.no);
        }
        catch (e) { /* 忽略关单失败以避免卡住取消流程 */ }
        return this.orders.cancelOrder(id, body?.reason, operatorUserId);
    }
    // 恢复软删除
    restore(id, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.restoreOrder(id, operatorUserId);
    }
    refund(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.refundOrder(id, body?.reason, operatorUserId);
    }
    // ========================
    // 售后与退款接口（会员发起）
    // ========================
    async createAfterSales(id, body, authHeader) {
        const memberId = this.extractMemberIdFromAuthHeader(authHeader);
        if (!memberId)
            throw new BadRequestException('未登录或身份无效');
        const req = await this.orders.createAfterSalesRequest({
            orderId: id,
            memberId,
            type: body.type,
            reasonCode: body.reasonCode || null,
            reasonText: body.reasonText || null,
            description: body.description || null,
            imagesJson: body.images ?? undefined,
            exchangeAddressSnapshot: body.exchangeAddress ?? undefined,
            requestedAmount: (typeof body.amount === 'number' && body.amount > 0) ? body.amount : undefined,
        });
        return req;
    }
    listAfterSales(status, memberIdStr) {
        const memberId = memberIdStr ? Number(memberIdStr) : undefined;
        return this.orders.listAfterSales({ status: status, memberId });
    }
    auditAfterSales(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        if (!operatorUserId)
            throw new BadRequestException('缺少管理员身份');
        return this.orders.auditAfterSales(id, !!body.approve, body?.remark, operatorUserId);
    }
    // 微信退款：供后台审核通过后调用或自动化
    async wechatRefund(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        if (!operatorUserId)
            throw new BadRequestException('缺少管理员身份');
        const order = await this.orders.getOrder(id);
        if (!order || order.payStatus !== 'PAID' || order.payMethod !== 'WECHAT_JSAPI')
            throw new BadRequestException('仅支持微信JSAPI已支付订单退款');
        const notifyUrl = (process.env.PUBLIC_API_BASE || '').replace(/\/$/, '') + '/orders/_notify/wechat-refund';
        const outRefundNo = `R_${order.no}_${Date.now()}`;
        const amountFen = Math.round(Number(order.payAmount) * 100);
        const requestedFen = Math.round(Number(body?.amount ?? order.payAmount) * 100);
        if (requestedFen <= 0)
            throw new BadRequestException('退款金额必须大于0');
        // 累计部分退款上限校验（SUCCESS 之和应 ≤ 实付）
        const existing = await this.orders.getOrder(id);
        const successSumFen = Math.round(((existing?.refundRecords || []).filter((r) => r.status === 'SUCCESS').reduce((s, r) => s + Number(r.amount || 0), 0)) * 100);
        const refundableFen = Math.max(0, amountFen - successSumFen);
        const refundFen = Math.min(requestedFen, refundableFen);
        if (refundFen <= 0)
            throw new BadRequestException('累计退款金额已达上限');
        // 校验全额退款可行性（如洗车卡剩余次数不足则阻断）
        const allowed = await this.orders.verifyRefundAllowed(order.id, refundFen / 100);
        if (!allowed)
            throw new BadRequestException('退款校验未通过：关联权益已部分使用，无法全额退款');
        const resp = await this.wxpay.createRefund({ outTradeNo: order.no, outRefundNo, refundAmountFen: refundFen, totalAmountFen: amountFen, reason: body?.reason, notifyUrl });
        await this.orders.createRefundRecord({ orderId: order.id, memberId: order.memberId, amount: (refundFen / 100), method: 'WECHAT_JSAPI', reasonCode: 'WECHAT', reasonText: body?.reason || null, outRefundNo, wechatRefundId: resp?.refund_id || null, status: 'PROCESSING' });
        return { ok: true, outRefundNo };
    }
    // 微信退款回调
    async wechatRefundNotify(req, res) {
        try {
            const body = req.body || {};
            const resource = body?.resource || {};
            if (!resource?.nonce || !resource?.associated_data || !resource?.ciphertext)
                throw new BadRequestException('非法通知');
            const decrypted = this.wxpay.decryptNotifyResource(resource.nonce, resource.associated_data, resource.ciphertext);
            const outRefundNo = decrypted?.out_refund_no;
            const refundId = decrypted?.refund_id;
            const status = decrypted?.refund_status; // SUCCESS, ABNORMAL, CLOSED
            if (outRefundNo) {
                if (status === 'SUCCESS') {
                    const rec = await this.orders.updateRefundStatusByOutRefundNo(outRefundNo, 'SUCCESS', refundId, null);
                    if (rec?.orderId) {
                        const amt = Number(rec?.amount || 0);
                        await this.orders.applyRefundSuccess({ orderId: rec.orderId, amountYuan: amt, method: 'WECHAT_JSAPI', operatorUserId: undefined });
                        await this.orders.completeLatestRefundAftersalesByOrder(rec.orderId, undefined);
                    }
                }
                else if (status === 'ABNORMAL') {
                    await this.orders.updateRefundStatusByOutRefundNo(outRefundNo, 'FAILED', refundId, decrypted?.status || 'ABNORMAL');
                }
                else if (status === 'CLOSED') {
                    await this.orders.updateRefundStatusByOutRefundNo(outRefundNo, 'CANCELLED', refundId, 'CLOSED');
                }
            }
            res.status(200).json({ code: 'SUCCESS' });
        }
        catch (e) {
            res.status(500).json({ code: 'ERROR', message: e?.message || String(e) });
        }
    }
    // 发货：无需快递或快递发货
    ship(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.shipOrder(id, operatorUserId, body);
    }
    // 收货
    receive(id, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.receiveOrder(id, operatorUserId);
    }
    // 开始服务
    startService(id, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.startService(id, operatorUserId);
    }
    // 结束服务
    finishService(id, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        return this.orders.finishService(id, operatorUserId);
    }
    // 评价接口（新增）
    async createReview(id, body, authHeader) {
        const memberId = this.extractMemberIdFromAuthHeader(authHeader);
        if (!memberId)
            throw new BadRequestException('未登录或身份无效');
        return this.orders.createOrderReview({ orderId: id, memberId, rating: body.rating, content: body.content, images: body.images });
    }
    getReview(id) {
        return this.orders.getOrderReviewByOrderId(id);
    }
    listReviews(page, pageSize, memberIdStr, orderNo, ratingMinStr, ratingMaxStr, start, end) {
        const memberId = memberIdStr ? Number(memberIdStr) : undefined;
        const ratingMin = ratingMinStr ? Number(ratingMinStr) : undefined;
        const ratingMax = ratingMaxStr ? Number(ratingMaxStr) : undefined;
        return this.orders.listReviews({ page: page ? Number(page) : undefined, pageSize: pageSize ? Number(pageSize) : undefined, memberId, orderNo, ratingMin, ratingMax, start, end });
    }
    deleteReview(id, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        if (!operatorUserId)
            throw new BadRequestException('无权限');
        return this.orders.deleteReview(id);
    }
    replyReview(id, body, authHeader) {
        const operatorUserId = this.extractAdminIdFromAuthHeader(authHeader);
        if (!operatorUserId)
            throw new BadRequestException('无权限');
        return this.orders.replyReview(id, body?.content || '', operatorUserId);
    }
    // 物流公司列表（探数）
    async getCompanies() {
        return await this.tanshu.getCompanies();
    }
    // 物流查询（探数 V2）- 管理端/小程序端均可调用（需网关限制实际部署时再加）
    async query(com, no, phone) {
        if (!no)
            return { code: 0, msg: 'no required' };
        return await this.tanshu.queryTracking({ com, no, phone });
    }
    extractAdminIdFromAuthHeader(authHeader) {
        if (!authHeader)
            return undefined;
        const m = /^Bearer\s+(.+)$/.exec(authHeader);
        const token = m?.[1];
        if (!token)
            return undefined;
        try {
            const decoded = this.jwt.verify(token);
            if (decoded?.type !== 'admin')
                return undefined;
            const id = Number(decoded?.sub);
            return Number.isFinite(id) && id > 0 ? id : undefined;
        }
        catch {
            return undefined;
        }
    }
    extractMemberIdFromAuthHeader(authHeader) {
        if (!authHeader)
            return undefined;
        const m = /^Bearer\s+(.+)$/.exec(authHeader);
        const token = m?.[1];
        if (!token)
            return undefined;
        try {
            const decoded = this.jwt.verify(token);
            if (decoded?.type !== 'member')
                return undefined;
            const id = Number(decoded?.sub);
            return Number.isFinite(id) && id > 0 ? id : undefined;
        }
        catch {
            return undefined;
        }
    }
};
__decorate([
    Post(''),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "create", null);
__decorate([
    Get(':id(\\d+)'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "get", null);
__decorate([
    Get('by-no/:no'),
    __param(0, Param('no')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "getByNo", null);
__decorate([
    Get(''),
    __param(0, Query('type')),
    __param(1, Query('status')),
    __param(2, Query('payStatus')),
    __param(3, Query('scene')),
    __param(4, Query('includeDeleted')),
    __param(5, Query('memberId')),
    __param(6, Query('keyword')),
    __param(7, Query('start')),
    __param(8, Query('end')),
    __param(9, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "list", null);
__decorate([
    Post(':id/pay/wechat-jsapi'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "wechatJsapi", null);
__decorate([
    Post('_notify/wechat'),
    __param(0, Req()),
    __param(1, Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "wechatNotify", null);
__decorate([
    Post(':id/pay/manual'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "markPaid", null);
__decorate([
    Post(':id/close'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "close", null);
__decorate([
    Post(':id/cancel'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "cancelOrder", null);
__decorate([
    Post(':id/restore'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "restore", null);
__decorate([
    Post(':id/refund'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "refund", null);
__decorate([
    Post(':id/after-sales'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "createAfterSales", null);
__decorate([
    Get('_after-sales'),
    UseGuards(AdminGuard),
    RequirePerm('after-sales'),
    __param(0, Query('status')),
    __param(1, Query('memberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "listAfterSales", null);
__decorate([
    Post('_after-sales/:id/audit'),
    UseGuards(AdminGuard),
    RequirePerm('after-sales'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "auditAfterSales", null);
__decorate([
    Post(':id/refund/wechat'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "wechatRefund", null);
__decorate([
    Post('_notify/wechat-refund'),
    __param(0, Req()),
    __param(1, Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "wechatRefundNotify", null);
__decorate([
    Post(':id/ship'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "ship", null);
__decorate([
    Post(':id/receive'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "receive", null);
__decorate([
    Post(':id/start-service'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "startService", null);
__decorate([
    Post(':id/finish-service'),
    UseGuards(AdminGuard),
    RequirePerm('orders'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "finishService", null);
__decorate([
    Post(':id/review'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "createReview", null);
__decorate([
    Get(':id/review'),
    __param(0, Param('id', ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "getReview", null);
__decorate([
    Get('_reviews'),
    UseGuards(AdminGuard),
    RequirePerm('content-reviews'),
    __param(0, Query('page')),
    __param(1, Query('pageSize')),
    __param(2, Query('memberId')),
    __param(3, Query('orderNo')),
    __param(4, Query('ratingMin')),
    __param(5, Query('ratingMax')),
    __param(6, Query('start')),
    __param(7, Query('end')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "listReviews", null);
__decorate([
    Post('_reviews/:id/delete'),
    UseGuards(AdminGuard),
    RequirePerm('content-reviews'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "deleteReview", null);
__decorate([
    Post('_reviews/:id/reply'),
    UseGuards(AdminGuard),
    RequirePerm('content-reviews'),
    __param(0, Param('id', ParseIntPipe)),
    __param(1, Body()),
    __param(2, Headers('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], OrderController.prototype, "replyReview", null);
__decorate([
    Get('/_logistics/companies'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getCompanies", null);
__decorate([
    Get('/_logistics/query'),
    __param(0, Query('com')),
    __param(1, Query('no')),
    __param(2, Query('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "query", null);
OrderController = __decorate([
    ApiTags('Order'),
    Controller('orders'),
    __metadata("design:paramtypes", [OrderService, JwtService, TanshuService, WxpayService])
], OrderController);
export { OrderController };
