var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from '../prisma.service.js';
import { OrderService } from './order.service.js';
import { TanshuService } from './tanshu.service.js';
import { OrderController } from './order.controller.js';
import { WxpayService } from './wxpay.service.js';
import { OrderTimeoutService } from './timeout.service.js';
let OrderModule = class OrderModule {
};
OrderModule = __decorate([
    Module({
        imports: [
            JwtModule.register({
                secret: process.env.JWT_SECRET || 'dev_secret',
            })
        ],
        controllers: [OrderController],
        providers: [PrismaService, OrderService, TanshuService, WxpayService, OrderTimeoutService],
    })
], OrderModule);
export { OrderModule };
