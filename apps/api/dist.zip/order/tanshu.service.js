var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@nestjs/common';
let TanshuService = class TanshuService {
    get apiKey() {
        try {
            return process.env.TANSHU_CAR_API_KEY
                || process.env.TANSHU_API_KEY
                || process.env.TS_API_KEY;
        }
        catch {
            return undefined;
        }
    }
    async requestJson(url) {
        try {
            const res = await fetch(url);
            const data = await res.json();
            return data;
        }
        catch {
            return null;
        }
    }
    async getCompanies() {
        // 探数“快递公司查询”接口：文档页提供 /api/exp/v1/com
        const url = `https://api.tanshuapi.com/api/exp/v1/com?key=${encodeURIComponent(this.apiKey || '')}`;
        const data = await this.requestJson(url);
        try {
            const list = Array.isArray(data?.data) ? data.data : [];
            return list.map((it) => ({ code: String(it?.com || it?.code || '').trim(), name: String(it?.company || it?.name || '').trim(), logo: String(it?.logo || it?.icon || '').trim() })).filter(x => x.code && x.name);
        }
        catch {
            return [];
        }
    }
    async queryTracking(params) {
        const key = this.apiKey || '';
        const qs = new URLSearchParams();
        if (params.com)
            qs.set('com', params.com);
        qs.set('no', params.no);
        if (params.phone)
            qs.set('phone', params.phone);
        const url = `https://api.tanshuapi.com/api/exp/v2/index?key=${encodeURIComponent(key)}&${qs.toString()}`;
        const data = await this.requestJson(url);
        return data;
    }
};
TanshuService = __decorate([
    Injectable()
], TanshuService);
export { TanshuService };
